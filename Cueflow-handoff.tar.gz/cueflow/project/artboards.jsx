/* artboards.jsx — CueFlow redesign screen content (loaded as Babel) */

/* ────────────────────────────────────────────
   small inline components & helpers
   ──────────────────────────────────────────── */
const Pip = ({k='ok', pulse}) => <span className={`pip ${k} ${pulse?'pulse':''}`}></span>;
const Bars = ({k='ok'}) => <span className={`bars ${k}`}><i/><i/><i/><i/></span>;
const Chip = ({k='ghost', children}) => <span className={`chip ${k}`}>{children}</span>;

/* CAMERA PALETTE — distinct, vivid, reserved for camera sub-tracks.
   Normal tracks NEVER use these. */
const CAMS = {
  1: { col: '#4cb1ff', bg: 'rgba(76,177,255,0.16)' },
  2: { col: '#ff5d8a', bg: 'rgba(255,93,138,0.16)' },
  3: { col: '#5ad79c', bg: 'rgba(90,215,156,0.16)' },
  4: { col: '#b08aff', bg: 'rgba(176,138,255,0.16)' },
  5: { col: '#ffb13c', bg: 'rgba(255,177,60,0.16)' },
  6: { col: '#4cdce6', bg: 'rgba(76,220,230,0.16)' },
  7: { col: '#ffd84d', bg: 'rgba(255,216,77,0.16)' },
  8: { col: '#e07cff', bg: 'rgba(224,124,255,0.16)' },
};
const camCol = (n) => CAMS[n]?.col || '#888';
const camBg  = (n) => CAMS[n]?.bg  || 'rgba(255,255,255,0.05)';

/* Camera badge — the most-used glyph in the system */
const CamBadge = ({n, size='md', outline=false}) => (
  <span
    className={`cam-badge ${size} ${outline?'outline':''}`}
    style={outline
      ? { color: camCol(n), background: 'transparent', borderColor: camCol(n) }
      : { background: camCol(n) }}
  >{String(n).padStart(2,'0')}</span>
);

/* "CAM" label + badge stack */
const CamStack = ({n, size='md', outline=false}) => (
  <span className="cam-wrap">
    <span className="cam-lbl">CAM</span>
    <CamBadge n={n} size={size} outline={outline}/>
  </span>
);

/* Normal-track glyph — quiet, typographic, no bright color */
const TrackGlyph = ({code, size='md'}) => (
  <span className={`trk-glyph ${size}`}>{code}</span>
);

/* SVG-ish waveform sample — varying bar heights */
const wfPattern = (n, seed=1, peakAt=0.5) => {
  const bars = [];
  for (let i = 0; i < n; i++) {
    const t = i / Math.max(1, n - 1);
    // gentle peak around peakAt, plus pseudo-randomness from seed
    const env = 1 - Math.abs(t - peakAt) * 1.4;
    const noise = Math.abs(Math.sin((i * 12.9898 + seed * 78.233)) * 43758.5453 % 1);
    bars.push(Math.max(0.18, Math.min(1, env * (0.55 + noise * 0.7))));
  }
  return bars;
};
const Waveform = ({n=80, seed=1, peakAt=0.5, maxH=24}) => (
  <span className="waveform">
    {wfPattern(n, seed, peakAt).map((v, i) => (
      <i key={i} style={{ height: Math.max(2, Math.round(v * maxH)) }}/>
    ))}
  </span>
);

/* icons — all square + fill/stroke explicit so they always render */
const IconUser = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>;
const IconList = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>;
const IconSeq = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>;
const IconTrk = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="3" width="18" height="4" rx="0.5"/><rect x="3" y="10" width="18" height="4" rx="0.5"/><rect x="3" y="17" width="18" height="4" rx="0.5"/></svg>;
const IconLink = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>;
const IconSet = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 01-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 01-4 0v-.1a1.7 1.7 0 00-1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 01-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 010-4h.1a1.7 1.7 0 001.5-1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 012.8-2.8l.1.1a1.7 1.7 0 001.8.3 1.7 1.7 0 001-1.5V3a2 2 0 014 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 012.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8 1.7 1.7 0 001.5 1H21a2 2 0 010 4h-.1a1.7 1.7 0 00-1.5 1z"/></svg>;
const IconKbd = () => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="2" y="6" width="20" height="13" rx="1"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M8 14h8"/></svg>;
const IconPlay = () => <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="6 4 20 12 6 20 6 4"/></svg>;
const IconStop = () => <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" stroke="none"><rect x="5" y="5" width="14" height="14"/></svg>;
const IconRewind = () => <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor" stroke="none"><polygon points="11 4 11 20 1 12"/><polygon points="22 4 22 20 12 12"/></svg>;
const IconFilt = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>;
const IconImp  = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>;
const IconExpand = () => <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"/></svg>;
const IconCollapse = () => <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 15 12 9 18 15"/></svg>;

/* shared rail (left sidebar) */
const Rail = ({active='seq'}) => (
  <aside className="rail">
    <button className={`rail-btn ${active==='acct'?'active':''}`}><IconUser/><span>ACCT</span></button>
    <button className={`rail-btn ${active==='share'?'active':''}`}><IconLink/><span>SHARE</span></button>
    <button className={`rail-btn ${active==='lists'?'active':''}`}><IconList/><span>LISTS</span></button>
    <button className={`rail-btn ${active==='seq'?'active':''}`}><IconSeq/><span>SEQ</span></button>
    <button className={`rail-btn ${active==='trk'?'active':''}`}><IconTrk/><span>TRACKS</span></button>
    <div className="rail-btn spacer"></div>
    <button className="rail-btn"><IconKbd/><span>KEYS</span></button>
    <button className="rail-btn"><IconSet/><span>SET</span></button>
  </aside>
);

/* ════════════════════════════════════════════
   COVER / DIRECTION
   ════════════════════════════════════════════ */
const CoverBoard = () => (
  <div className="ab" style={{padding:'80px 80px', justifyContent:'space-between'}}>
    <div>
      <div style={{display:'flex',alignItems:'center',gap:18,marginBottom:48}}>
        <div style={{width:24,height:24,background:'var(--amber)'}}></div>
        <div style={{fontFamily:'var(--cond)',fontSize:11,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--txt-mid)'}}>CueFlow / Redesign / v2</div>
      </div>
      <h1 style={{fontFamily:'var(--cond)',fontSize:120,fontWeight:700,lineHeight:0.92,letterSpacing:'-0.02em',color:'var(--txt-hi)',textTransform:'uppercase'}}>
        Next cue,<br/>not now cue.
      </h1>
      <p style={{fontSize:22,lineHeight:1.45,color:'var(--txt)',marginTop:36,maxWidth:'60ch'}}>
        A control surface for live production. Re-anchored: <span style={{color:'var(--amber)'}}>the question an operator asks is "what's coming and when?"</span> — so that's the part of the screen that gets the type.
      </p>
    </div>

    <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:32,paddingTop:48,borderTop:'1px solid var(--hair2)'}}>
      <div>
        <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--amber)',marginBottom:8}}>01 — TC demoted</div>
        <div style={{fontFamily:'var(--cond)',fontSize:16,fontWeight:600,color:'var(--txt-hi)',lineHeight:1.25}}>Visible, but not the hero. NEXT cue + 5-deep queue takes the screen.</div>
      </div>
      <div>
        <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--amber)',marginBottom:8}}>02 — Cameras are numbers</div>
        <div style={{fontFamily:'var(--cond)',fontSize:16,fontWeight:600,color:'var(--txt-hi)',lineHeight:1.25}}>Numbered sub-tracks with their own color. Big badges in live, list, timeline — no hunting.</div>
      </div>
      <div>
        <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--amber)',marginBottom:8}}>03 — Normal tracks are quiet</div>
        <div style={{fontFamily:'var(--cond)',fontSize:16,fontWeight:600,color:'var(--txt-hi)',lineHeight:1.25}}>Typographic glyphs, no bright color. Color is reserved for cameras + state.</div>
      </div>
      <div>
        <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--amber)',marginBottom:8}}>04 — Setlist always-on</div>
        <div style={{fontFamily:'var(--cond)',fontSize:16,fontWeight:600,color:'var(--txt-hi)',lineHeight:1.25}}>Full show, low contrast, peripheral. The operator never loses the shape of the night.</div>
      </div>
    </div>
  </div>
);

/* ════════════════════════════════════════════
   ANALYSIS BOARD
   ════════════════════════════════════════════ */
const AnalysisBoard = () => {
  const issues = [
    ['01','Live view is a slightly-changed edit view','Same sidebar, similar topbar, same shell. The operator can\'t feel the mode change in their peripheral vision.'],
    ['02','TC dominates, but isn\'t the question','The operator already feels the show TC in their body — what they need from a glance is "what fires next, and when". That data wasn\'t there.'],
    ['03','No countdown to next event','The most operationally useful number — seconds until the next cue — didn\'t exist on screen. People were subtracting TC values in their head.'],
    ['04','Cameras lost in the data','Camera number — the most important identifier for a multicam shoot — was a tiny color swatch. Now it\'s a chunky numbered badge everywhere.'],
    ['05','All tracks shout the same','Bright colors on every track ⇒ nothing pops. Cameras own color; normal tracks (audio/lx/vid) are typographic and quiet.'],
    ['06','TC connection state is whispered','"Connect TC" was a small button. Sync loss is a top-shelf failure — it now has a permanent status bar.'],
    ['07','The Live ↔ Edit toggle is a normal button','Most dangerous action in the UI; visually weighted to demand deliberate intent.'],
    ['08','No upcoming-cue prominence','"Up next" was a side panel. Now: hero cue + 4 more queued, always.'],
  ];
  const wins = [
    ['Multi-track data model','Already supports parallel cue lanes + camera sub-tracks — kept, just surfaced harder.'],
    ['Waterfall concept','Right idea — time-sorted upcoming cues — needed to lose the spreadsheet shell.'],
    ['Sequence/song decomposition','Maps cleanly onto how operators think about a show.'],
    ['MTC/LTC support','Real broadcast plumbing — must be celebrated in the chrome.'],
    ['Camera sub-tracks','Already in the data; the visual treatment just needed to catch up.'],
  ];
  return (
    <div className="ab analysis">
      <h1>What's not yet trustworthy.</h1>
      <p className="lede">
        CueFlow already has the plumbing — multi-track cues, MTC/LTC sync, sequences, sharing. The interface, though, asked the operator to <strong>read and interpret</strong> when it should let them <strong>glance and trust</strong>. Below: issues, then what to keep.
      </p>

      <div className="an-col">
        <h2 className="red">Issues — Live view</h2>
        {issues.map(([i,t,b])=>(
          <div className="an-item" key={i}>
            <div className="ix">{i}</div>
            <div>
              <div className="ti">{t}</div>
              <div className="bd">{b}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="an-col">
        <h2 className="green">Keep & strengthen</h2>
        {wins.map(([t,b],i)=>(
          <div className="an-item" key={i}>
            <div className="ix">+{(i+1).toString().padStart(2,'0')}</div>
            <div>
              <div className="ti">{t}</div>
              <div className="bd">{b}</div>
            </div>
          </div>
        ))}

        <h2 style={{marginTop:40}}>Operating principles</h2>
        {[
          ['Eyes return for <1s','Information density in live is calibrated to a glance, not a read.'],
          ['Mode separation is architectural','Live and Edit don\'t share a shell. Switching is a deliberate gesture.'],
          ['Trust signals always-on','TC lock, FPS, drift, sharing — all visible without any hover or click.'],
          ['Color is for state, not decoration','Tally red = on air. Amber = standby/next. Camera colors only ever mean their camera. Nothing else gets color.'],
        ].map(([t,b],i)=>(
          <div className="an-item" key={i}>
            <div className="ix">P{i+1}</div>
            <div>
              <div className="ti">{t}</div>
              <div className="bd">{b}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

/* ════════════════════════════════════════════
   LIVE — Show data (one source for all live states)
   ════════════════════════════════════════════ */
/* Camera cue data — cues live on ONE camera track. Each cue ends
   when the next cue begins (no end times). connectCues() turns
   {n, l (left%)} into {n, l, w} by reading the next cue's left. */
const _CAM_CUES_RAW = [
  {n:3, l:1,    nm:'Mid drummer'},
  {n:1, l:11,   nm:'Wide drone'},
  {n:2, l:22,   nm:'Wide pull SR', current:true},
  {n:4, l:37,   nm:'Close · vocal'},
  {n:1, l:55,   nm:'Wide drone'},
  {n:3, l:74,   nm:'Mid drummer'},
  {n:5, l:85,   nm:'Wide audience'},
  {n:4, l:94,   nm:'Close · guitar'},
];
/* Last cue runs to the sequence-end marker (which doesn't exist —
   so we run to 100% with a soft right edge handled in CSS). */
const connectCues = (cues, endAt = 100) =>
  cues.map((c, i) => ({
    ...c,
    l: c.l + '%',
    w: ((i < cues.length - 1 ? cues[i+1].l : endAt) - c.l) + '%',
  }));
const CAM_CUES = connectCues(_CAM_CUES_RAW);

const CamCue = ({cue}) => (
  <div className={`tl-cue cam ${cue.current?'current':''}`}
       style={{left:cue.l, width:cue.w, '--cam-col': camCol(cue.n), '--cam-bg': camBg(cue.n)}}>
    <span className="tl-cam-num">{String(cue.n).padStart(2,'0')}</span>
    <span>{cue.nm}</span>
  </div>
);

/* Cameras live on ONE track only — never collapse/expand */
const TimelineCamLane = () => (
  <div className="tl-lane cam-row">
    <div className="tl-lane-head">
      <span style={{fontFamily:'var(--cond)',fontSize:11,fontWeight:700,letterSpacing:'.12em'}}>CAMERAS</span>
      <span style={{flex:1}}></span>
      <span style={{fontFamily:'var(--mono)',fontSize:9,color:'var(--txt-low)'}}>×5 cams</span>
    </div>
    <div className="tl-lane-body">
      {CAM_CUES.map((c,i)=><CamCue key={i} cue={c}/>)}
    </div>
  </div>
);

/* helpers for connecting normal-track cues */
const _LX_RAW = [
  {l:2, nm:'Verse wash 60%'},
  {l:22, nm:'Chorus build'},
  {l:37, nm:'Confetti / strobe'},
  {l:55, nm:'Bridge wash'},
  {l:74, nm:'Out wash'},
];
const LX_CUES = connectCues(_LX_RAW);

const _VID_RAW = [
  {l:10, nm:'IMAG live'},
  {l:42, nm:'Lyric plate'},
  {l:56, nm:'Crowd cam'},
  {l:85, nm:'Logo plate'},
];
const VID_CUES = connectCues(_VID_RAW);

const SHOW = {
  name: 'Arena Tour 2026 — Brisbane',
  sequences: [
    {n: 1,  nm: 'Pre-show',            dur: '12:00', state: 'done'},
    {n: 2,  nm: 'Walk-on',             dur: '1:30',  state: 'done'},
    {n: 3,  nm: 'Intro VT',            dur: '2:14',  state: 'done'},
    {n: 4,  nm: 'Velocity (opener)',   dur: '4:32',  state: 'now',  progress: 0.38},
    {n: 5,  nm: 'Hello Brisbane',      dur: '3:18',  state: 'next'},
    {n: 6,  nm: 'Hit Single',          dur: '3:42',  state: ''},
    {n: 7,  nm: 'Ballad — Smaller',    dur: '5:01',  state: ''},
    {n: 8,  nm: 'Costume change VT',   dur: '1:50',  state: ''},
    {n: 9,  nm: 'Dance break',         dur: '4:12',  state: ''},
    {n: 10, nm: 'Encore',              dur: '2:30',  state: ''},
    {n: 11, nm: 'Bow',                 dur: '1:00',  state: ''},
    {n: 12, nm: 'Outro music',         dur: '3:00',  state: ''},
  ],
};

const Setlist = ({label='Setlist'}) => (
  <div className="setlist">
    <div className="setlist-head">
      <span className="lbl">{label}</span>
      <span className="meta">3 / 12 · 18:42 in</span>
    </div>
    <div className="setlist-body">
      {SHOW.sequences.map(s => (
        <div className={`sl-item ${s.state}`} key={s.n} style={s.progress?{'--p': (s.progress*100)+'%'}:{}}>
          <span className="ix">{String(s.n).padStart(2,'0')}</span>
          <span className="nm">{s.nm}</span>
          <span className="dur">{s.dur}</span>
          {s.state === 'now' && <span className="sl-prog"></span>}
        </div>
      ))}
    </div>
  </div>
);

/* ════════════════════════════════════════════
   LIVE — On-air cockpit (NEXT-led)
   states: 'on-air' | 'warn' | 'pre-show'
   ════════════════════════════════════════════ */
const LiveCockpit = ({state='on-air'}) => {
  const isWarn = state === 'warn';
  const isPre  = state === 'pre-show';

  // upcoming cue queue (NEXT + 4 more, mixed tracks). cdSec drives
  // the per-cue urgency bar — visible when ≤ 20s, red when ≤ 10s.
  const queue = isPre
    ? [
        {type:'cam', cam:1, name:'Walk-on',           desc:'House lights to half, cam 01 walk-on shot', tc:'01:00:00:00', cd:'—:—', cdSec: null},
        {type:'norm', trk:'LX',  name:'House to half',     desc:'',                                     tc:'01:00:00:00', cd:'—:—', cdSec: null},
        {type:'norm', trk:'AUD', name:'Walk-on bed fade',  desc:'',                                     tc:'01:00:02:00', cd:'—:—', cdSec: null},
        {type:'norm', trk:'VID', name:'Logo plate · 4s',   desc:'',                                     tc:'01:00:04:00', cd:'—:—', cdSec: null},
        {type:'cam', cam:2, name:'Lead vocal close',  desc:'',                                          tc:'01:00:06:12', cd:'—:—', cdSec: null},
      ]
    : [
        {type:'cam', cam:4, name:'Close · vocal',     desc:'Tight on lead vocal',          tc:'01:23:47:24', cd: isWarn?'0:06':'0:12', cdSec: isWarn?6:12},
        {type:'norm', trk:'LX',  name:'Chorus build', desc:'Build to full intensity',      tc:'01:23:47:24', cd:'0:12', cdSec: 12},
        {type:'cam', cam:1, name:'Wide · drone over',desc:'Aerial sweep stage → audience', tc:'01:23:54:00', cd:'0:18', cdSec: 18},
        {type:'norm', trk:'VID', name:'Lyric plate',  desc:'Title overlay "Velocity"',     tc:'01:23:56:18', cd:'0:24', cdSec: 24},
        {type:'cam', cam:3, name:'Mid · drummer',     desc:'Wide → mid push',              tc:'01:24:02:12', cd:'1:50', cdSec: 110},
      ];
  const next = queue[0];
  const then = queue.slice(1);

  // current on-air cue
  const onAir = {cam: 2, name:'Wide pull · stage right', held:'0:42', tc:'01:23:45:00'};

  return (
    <div className="ab live">
      {/* STATUS BAR — small TC, all trust signals */}
      <div className="statusbar live-statusbar">
        <div className="sb-cell">
          {isPre ? <Pip k="idle"/> : <Bars k="ok"/>}
          <strong>TC IN</strong>
          <span className="sb-val">{isPre?'NO SIGNAL':'LTC · LOCKSTEP'}</span>
        </div>
        <div className="sb-cell">
          <strong>TIMECODE</strong>
          <span className="sb-val tc" style={{fontSize:14}}>{isPre?'—:—:—:—':`01:23:${isWarn?'47:18':'45:12'}`}</span>
        </div>
        <div className="sb-cell"><strong>FPS</strong><span className="sb-val">25.000</span></div>
        <div className="sb-cell"><strong>DRIFT</strong><span className="sb-val" style={{color: isPre?'var(--txt-low)':'var(--green)'}}>{isPre?'—':'±0.4 ms'}</span></div>
        <div className="sb-cell grow">
          <strong>SHARING</strong>
          <Pip k="ok"/>
          <span className="sb-val">4 peers · OWNER</span>
        </div>
        <div className="sb-cell right">
          <Chip k={isPre?'amber':'red'}>{isPre?'STANDBY':'● ON AIR'}</Chip>
        </div>
        <div className="sb-cell" style={{borderRight:'none'}}>
          <strong style={{color:'var(--txt-low)'}}>EXIT</strong>
          <span style={{fontFamily:'var(--mono)',fontSize:10,padding:'2px 6px',border:'1px solid var(--hair2)',color:'var(--txt-mid)'}}>⇧ESC</span>
        </div>
      </div>
      <div className={`mode-banner ${isPre?'edit':''}`}></div>

      <div className="live-body">
        <div className="live-focal">
          {/* ON AIR strip — quiet, factual */}
          <div className="onair-strip">
            <div>
              <div className="onair-lbl"><Pip k="live" pulse={!isPre}/>{isPre?'STANDBY · NO TC':'ON AIR · CUE 17 / 84'}</div>
              <div style={{fontFamily:'var(--cond)',fontSize:11,letterSpacing:'.18em',textTransform:'uppercase',color:'var(--txt-mid)',marginTop:6}}>
                Seq {String(SHOW.sequences.find(s=>s.state==='now').n).padStart(2,'0')} · {SHOW.sequences.find(s=>s.state==='now').nm}
              </div>
            </div>
            <div className="onair-mid">
              {isPre
                ? <span style={{fontFamily:'var(--cond)',fontSize:22,color:'var(--txt-mid)',textTransform:'uppercase'}}>— Waiting for TC —</span>
                : <>
                    <CamBadge n={onAir.cam} size="md"/>
                    <span className="onair-name">{onAir.name}</span>
                  </>}
            </div>
            <div className="onair-held">
              <span>{isPre?'':'Held for'}</span>
              <span className="v tc">{isPre?'—:—':onAir.held}</span>
            </div>
          </div>

          {/* NEXT HERO — the dominant block */}
          <div className={`next-hero ${isWarn?'warn':''}`}>
            <div className="nh-eyebrow">
              <Pip k={isWarn?'live':'warn'} pulse={isWarn||!isPre}/>
              {isPre ? 'First cue — ready' : (isWarn ? 'Standby · GO' : 'Next cue')}
            </div>

            {/* badge or trk glyph */}
            <div>
              {next.type === 'cam'
                ? <CamBadge n={next.cam} size="lg"/>
                : <TrackGlyph code={next.trk} size="lg"/>}
            </div>

            <div style={{minWidth:0}}>
              <div className="nh-name">{next.name}</div>
              {next.desc && <div className="nh-desc">{next.desc}</div>}
            </div>

            <div className={`nh-count ${isWarn?'warn':''}`}>
              <div className="v tc">{next.cd}</div>
              <div className="lbl">until go</div>
            </div>

            {/* Glance-scannable countdown bar — grows toward GO */}
            <div className="nh-bar-scale">
              <i style={{left:'25%'}}></i><span style={{left:'25%'}}>15</span>
              <i style={{left:'50%'}}></i><span style={{left:'50%'}}>10</span>
              <i style={{left:'75%'}}></i><span style={{left:'75%'}}>5</span>
              <i style={{left:'100%'}}></i><span style={{left:'97%'}}>0</span>
            </div>
            <div className="nh-bar">
              <div className="fill" style={{width: isPre?'0%' : (isWarn?'70%':'40%')}}></div>
            </div>
          </div>

          {/* THEN — next 4 cues */}
          <div className="then-queue">
            <div className="then-head">
              <span className="lbl">Then · next 4 cues</span>
              <span className="meta">Sequence 04 · 5 more in sequence</span>
            </div>
            {then.map((q,i) => {
              const cdSec = q.cdSec;
              const urgent = cdSec != null && cdSec <= 10;
              const showBar = cdSec != null && cdSec <= 20;
              const fillPct = cdSec != null ? Math.max(0, Math.min(100, (20 - cdSec) / 20 * 100)) : 0;
              return (
                <div className="then-row" key={i}>
                  <div className="ix">+{i+1}</div>
                  <div className="tag">
                    {q.type === 'cam'
                      ? <CamBadge n={q.cam} size="sm"/>
                      : <TrackGlyph code={q.trk} size="sm"/>}
                  </div>
                  <div className="nm">
                    {q.name}
                    {q.desc && <span className="ds">{q.desc}</span>}
                  </div>
                  <div className="tc">{q.tc}</div>
                  <div className={`cd ${urgent?'urgent':(showBar?'warn':'')}`}>{q.cd}</div>
                  {showBar && (
                    <div className={`urg-bar ${urgent?'urgent':''}`}>
                      <div className="urg-fill" style={{width: fillPct+'%'}}></div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* SETLIST — peripheral */}
        <Setlist/>
      </div>

      <div className="live-foot">
        <span className="lf-lbl">Show progress</span>
        <span className="lf-pos tc">18:42 in · {SHOW.sequences.filter(s=>s.state==='done').length}/{SHOW.sequences.length} sequences complete</span>
        <span className="lf-track">
          <span className="lf-track-fill" style={{width: isPre?'0%':'18%'}}></span>
        </span>
        <span className="lf-eta tc">~ 1:42:15 remaining</span>
        <span className="grow"></span>
        <span style={{color:'var(--txt-low)'}}>v18.3 · read-only · {isPre?'Hold for TC':isWarn?'Standby':'Locked'}</span>
      </div>
    </div>
  );
};

/* ════════════════════════════════════════════
   CAMERA-OP VIEWER — held hero on top; below splits
   into MY SHOTS + optional ALL CAMS, both visible at once.
   ════════════════════════════════════════════ */
const CameraOp = ({allCamsOn=true, frame='full'}) => {
  // currently on-air
  const on = {cam: 2, name:'Wide pull · stage right', desc:'Hold wide thru verse 2. Punch on downbeat.', held:'0:42', cutIn:'0:12'};
  // single-track upcoming — only THIS operator's cues
  const myUpcoming = [
    {nm:'Close · guitar SR',  ds:'Tight on guitar solo',                  tc:'01:24:42:00', cd:'2:42', cdSec: 162},
    {nm:'Wide pull · SR',      ds:'Re-establish wide post-bridge',         tc:'01:24:54:00', cd:'3:42', cdSec: 222},
    {nm:'Mid · guitar',        ds:'Mid lock through chorus',               tc:'01:25:18:00', cd:'5:18', cdSec: 318},
    {nm:'Wide · audience-side',ds:'Pull to audience pan',                  tc:'01:26:00:00', cd:'6:18', cdSec: 378},
  ];
  // all-cams alt view — every cam's upcoming cue
  const allCams = [
    {cam:4, nm:'Close · vocal',     tc:'01:23:47:24', cd:'0:12', cdSec: 12},
    {cam:1, nm:'Wide · drone',      tc:'01:23:54:00', cd:'0:18', cdSec: 18},
    {cam:3, nm:'Mid · drummer',     tc:'01:24:02:12', cd:'1:50', cdSec: 110},
    {cam:5, nm:'Wide · audience',   tc:'01:24:08:00', cd:'2:08', cdSec: 128},
    {cam:4, nm:'Close · guitar SR', tc:'01:24:42:00', cd:'2:42', cdSec: 162},
    {cam:1, nm:'Wide · drone',      tc:'01:25:00:00', cd:'3:18', cdSec: 198},
  ];
  // Cut-in fill — 0s → 100%, 12s → 100*(20-12)/20 = 40%
  const cutSec = 12;
  const cutFill = Math.max(0, Math.min(100, (20 - cutSec)/20 * 100));
  const cutUrgent = cutSec <= 10;

  return (
    <div className={`ab ${frame}`}>
      <div className="statusbar live-statusbar">
        <div className="sb-cell"><Bars k="ok"/><strong>TC</strong><span className="sb-val tc" style={{fontSize:13}}>01:23:45:12</span></div>
        <div className="sb-cell"><strong>FPS</strong><span className="sb-val">25</span></div>
        <div className="sb-cell"><strong>OPERATOR</strong><span className="sb-val">M. KAUR · CAM 02</span></div>
        <div className="sb-cell grow"><strong>SEQ</strong><span className="sb-val">04 · Velocity</span></div>
        <div className="sb-cell right"><Chip k="red">● ON AIR</Chip></div>
      </div>
      <div className="mode-banner"></div>

      <div className="camop">
        {/* HELD HERO — the headline */}
        <div className={`held-hero ${cutUrgent?'urgent':''}`}
             style={{'--cam-col': camCol(on.cam), '--cam-bg': camBg(on.cam)}}>
          <CamBadge n={on.cam} size="xl"/>
          <div className="held-meta">
            <div className="eyebrow"><Pip k="live" pulse/>On camera</div>
            <div className="held-name">{on.name}</div>
            <div className="held-desc">{on.desc}</div>
          </div>
          <div style={{flex:1}}></div>
          <div className="held-timer">
            <div>
              <div className="lbl">Held for</div>
              <div className="v tc">{on.held}</div>
            </div>
            <div style={{height:18}}></div>
            <div>
              <div className="lbl">Cut in</div>
              <div className="v tc" style={{fontSize:64,color:cutUrgent?'#fff':'rgba(255,255,255,0.95)'}}>{on.cutIn}</div>
            </div>
          </div>
          <div className="cut-bar"><div className="fill" style={{width: cutFill+'%'}}></div></div>
        </div>

        {/* Split view — MY SHOTS + optional ALL CAMS, both in-window */}
        <div className={`camop-split ${allCamsOn?'':'solo'}`}>
          {/* My shots — always visible */}
          <div className="camop-col">
            <div className="camop-col-head">
              <div>
                <div className="lbl cam-on" style={{color: camCol(2)}}>● My next shots · CAM 02</div>
                <div style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--txt-low)',marginTop:4}}>{myUpcoming.length} in sequence 04</div>
              </div>
              <button className={`camop-col-toggle ${allCamsOn?'on':''}`}>
                {allCamsOn ? '✕ Hide all cams' : '◧ Show all cams'}
              </button>
            </div>
            <div className="camop-col-body">
              {myUpcoming.map((q,i) => {
                const urgent = q.cdSec <= 10;
                const showBar = q.cdSec <= 20;
                const fillPct = Math.max(0, Math.min(100, (20 - q.cdSec) / 20 * 100));
                return (
                  <div className="camop-row" key={i}>
                    <div className="ix">+{i+1}</div>
                    <div></div>
                    <div className="nm">{q.nm}{q.ds && <span className="ds">{q.ds}</span>}</div>
                    <div className="tc">{q.tc}</div>
                    <div className={`cd ${urgent?'urgent':(showBar?'warn':'')}`}>{q.cd}</div>
                    {showBar && (
                      <div className={`urg-bar ${urgent?'urgent':''}`}>
                        <div className="urg-fill" style={{width: fillPct+'%'}}></div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {allCamsOn && <div className="sep"></div>}

          {/* All cams — optional */}
          {allCamsOn && (
            <div className="camop-col">
              <div className="camop-col-head">
                <div>
                  <div className="lbl">All cameras · upcoming</div>
                  <div style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--txt-low)',marginTop:4}}>{allCams.length} cuts across 5 cams</div>
                </div>
              </div>
              <div className="camop-col-body">
                {allCams.map((q,i) => {
                  const urgent = q.cdSec <= 10;
                  const showBar = q.cdSec <= 20;
                  const fillPct = Math.max(0, Math.min(100, (20 - q.cdSec) / 20 * 100));
                  const mine = q.cam === 2;
                  return (
                    <div className="camop-row" key={i} style={mine?{background:'rgba(255,93,138,0.04)',borderLeft:`2px solid ${camCol(2)}`,paddingLeft:8,marginLeft:-10}:{}}>
                      <div className="ix">+{i+1}</div>
                      <div><CamBadge n={q.cam} size="sm"/></div>
                      <div className="nm">{q.nm}</div>
                      <div className="tc">{q.tc}</div>
                      <div className={`cd ${urgent?'urgent':(showBar?'warn':'')}`}>{q.cd}</div>
                      {showBar && (
                        <div className={`urg-bar ${urgent?'urgent':''}`}>
                          <div className="urg-fill" style={{width: fillPct+'%'}}></div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="live-foot">
          <span className="lf-lbl">Camera focus</span>
          <span className="lf-pos tc">CAM 02 · held 0:42 · cut in 0:12</span>
          <span className="lf-track"><span className="lf-track-fill" style={{width:'42%'}}></span></span>
          <span className="lf-eta tc">~ 1:42:15 remaining</span>
          <span className="grow"></span>
          <span style={{color:'var(--txt-low)'}}>read-only · feed mirrored</span>
        </div>
      </div>
    </div>
  );
};

/* ════════════════════════════════════════════
   NORMAL-TRACK VIEWER (e.g. Lighting op)
   Same shape as the on-air view but without camera badges;
   uses the track's SHORT name everywhere.
   ════════════════════════════════════════════ */
const TrackViewer = ({track={short:'LX', full:'Lighting'}, frame='full'}) => {
  const on = {nm:'Verse wash · 60%', ds:'Warm wash, 60% intensity, hold through verse 2', held:'0:18'};
  const upcoming = [
    {nm:'Chorus build',      ds:'Build to full intensity',      tc:'01:23:47:24', cd:'0:12', cdSec:12},
    {nm:'Confetti / strobe', ds:'Pyro 03 trigger window',       tc:'01:23:54:00', cd:'0:18', cdSec:18},
    {nm:'Bridge wash',       ds:'Cool blue, 80%',               tc:'01:24:02:12', cd:'1:50', cdSec:110},
    {nm:'Out wash',          ds:'House to half',                tc:'01:24:48:00', cd:'5:24', cdSec:324},
  ];
  return (
    <div className={`ab ${frame}`}>
      <div className="statusbar live-statusbar">
        <div className="sb-cell"><Bars k="ok"/><strong>TC</strong><span className="sb-val tc" style={{fontSize:13}}>01:23:45:12</span></div>
        <div className="sb-cell"><strong>FPS</strong><span className="sb-val">25</span></div>
        <div className="sb-cell"><strong>OPERATOR</strong><span className="sb-val">A. PETRESCU · {track.short}</span></div>
        <div className="sb-cell grow"><strong>SEQ</strong><span className="sb-val">04 · Velocity</span></div>
        <div className="sb-cell right"><Chip k="red">● ON AIR</Chip></div>
      </div>
      <div className="mode-banner"></div>

      <div className="vwr">
        <div className="vwr-onair">
          <div>
            <div className="lbl"><Pip k="live" pulse/>{track.full} · ON</div>
            <TrackGlyph code={track.short} size="lg" style={{marginTop:10}}/>
          </div>
          <div>
            <div className="nm">{on.nm}</div>
            <div style={{fontFamily:'var(--sans)',fontSize:14,color:'var(--txt)',marginTop:8,maxWidth:'56ch',lineHeight:1.45}}>{on.ds}</div>
          </div>
          <div className="held">
            <span className="lbl-s">Held for</span>
            {on.held}
          </div>
        </div>

        <div className="camop-up">
          <div className="upe-head">
            <span className="lbl">My next cues · {track.full}</span>
            <span className="meta">{upcoming.length} in sequence 04</span>
          </div>
          {upcoming.map((q,i)=>{
            const urgent = q.cdSec <= 10;
            const showBar = q.cdSec <= 20;
            const fillPct = Math.max(0, Math.min(100, (20 - q.cdSec) / 20 * 100));
            return (
              <div className="camop-row" key={i}>
                <div className="ix">+{i+1}</div>
                <div><TrackGlyph code={track.short} size="sm"/></div>
                <div className="nm">{q.nm}{q.ds && <span className="ds">{q.ds}</span>}</div>
                <div className="tc">{q.tc}</div>
                <div className={`cd ${urgent?'urgent':(showBar?'warn':'')}`}>{q.cd}</div>
                {showBar && (
                  <div className={`urg-bar ${urgent?'urgent':''}`}>
                    <div className="urg-fill" style={{width: fillPct+'%'}}></div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="live-foot">
          <span className="lf-lbl">Show progress</span>
          <span className="lf-pos tc">{track.short} · sequence 04 · 3 done · 6 to go</span>
          <span className="lf-track"><span className="lf-track-fill" style={{width:'38%'}}></span></span>
          <span className="lf-eta tc">~ 1:42:15 remaining</span>
          <span className="grow"></span>
          <span style={{color:'var(--txt-low)'}}>read-only</span>
        </div>
      </div>
    </div>
  );
};

/* ════════════════════════════════════════════
   TC VIEWER — for stage manager / iso display.
   Just the timecode, big as the screen allows.
   ════════════════════════════════════════════ */
const TCViewer = ({state='on-air', frame='full'}) => {
  const isPre = state === 'pre-show';
  return (
    <div className={`ab ${frame}`}>
      <div className="tcview">
        <div className="tcview-head">
          <span className="eyebrow"><Pip k={isPre?'idle':'ok'} pulse={!isPre}/>{isPre?'NO SIGNAL':'LTC · LOCKSTEP'}</span>
          <span className="eyebrow">CueFlow · TC display</span>
        </div>
        <div className="tcview-body">
          <div className={`tcv tc ${isPre?'':'live'}`}>
            {isPre ? '——:——:——:——' : '01:23:45:12'}
          </div>
        </div>
        <div className="tcview-foot">
          <div className="col">
            <div className="lbl">Sequence</div>
            <div className="v">04 · Velocity</div>
          </div>
          <div className="col" style={{textAlign:'right'}}>
            <div className="lbl">Next cue · {isPre?'first cue':'in'}</div>
            <div className="v"><span className="tc" style={{color:'var(--amber)'}}>{isPre?'—:—':'0:12'}</span> · close · vocal</div>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ════════════════════════════════════════════
   MOBILE viewer — phone-sized layout of the
   camera-op viewer. Stack the held hero vertically,
   shrink TC, drop chrome.
   ════════════════════════════════════════════ */
const MobileCameraOp = () => (
  <div className="ab" style={{background:'#050507'}}>
    <div className="vwr-mobile-bar">
      <span>CAM 02 · MY VIEW</span>
      <span className="tc">01:23:45</span>
      <span style={{color:'var(--red)'}}>● ON AIR</span>
    </div>

    <div className="vwr-mobile">
      {/* compact held block */}
      <div style={{padding:'18px 18px 22px',background:camBg(2),borderBottom:`2px solid ${camCol(2)}`,position:'relative'}}>
        <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.22em',textTransform:'uppercase',color:'rgba(255,255,255,0.7)',display:'flex',alignItems:'center',gap:6,marginBottom:12}}>
          <Pip k="live" pulse/>On camera
        </div>
        <div style={{display:'grid',gridTemplateColumns:'auto 1fr',gap:14,alignItems:'center'}}>
          <CamBadge n={2} size="lg"/>
          <div>
            <div style={{fontFamily:'var(--cond)',fontSize:24,fontWeight:700,color:'#fff',textTransform:'uppercase',lineHeight:1.05}}>Wide pull · SR</div>
            <div style={{fontFamily:'var(--sans)',fontSize:12,color:'rgba(255,255,255,0.85)',marginTop:6,lineHeight:1.4}}>Hold wide thru verse 2.</div>
          </div>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',marginTop:16,gap:14}}>
          <div>
            <div style={{fontFamily:'var(--cond)',fontSize:9,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'rgba(255,255,255,0.6)'}}>Held</div>
            <div className="tc" style={{fontFamily:'var(--mono)',fontSize:36,fontWeight:700,color:'#fff',lineHeight:1}}>0:42</div>
          </div>
          <div style={{textAlign:'right'}}>
            <div style={{fontFamily:'var(--cond)',fontSize:9,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'rgba(255,255,255,0.6)'}}>Cut in</div>
            <div className="tc" style={{fontFamily:'var(--mono)',fontSize:48,fontWeight:700,color:'#fff',lineHeight:1}}>0:12</div>
          </div>
        </div>
        <div style={{position:'absolute',left:0,right:0,bottom:0,height:6,background:'rgba(0,0,0,0.4)'}}>
          <div style={{height:'100%',width:'40%',background:'#fff',animation:'cutPulse .8s ease-in-out infinite'}}></div>
        </div>
      </div>

      {/* upcoming */}
      <div style={{padding:'12px 18px',flex:1,overflow:'hidden'}}>
        <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.22em',textTransform:'uppercase',color:'var(--txt-mid)',marginBottom:10}}>My next shots</div>
        {[
          ['Close · guitar SR','01:24:42','2:42'],
          ['Wide pull · SR',   '01:24:54','3:42'],
          ['Mid · guitar',     '01:25:18','5:18'],
        ].map(([nm,tc,cd],i)=>(
          <div key={i} style={{display:'grid',gridTemplateColumns:'1fr auto',padding:'10px 0',borderBottom:'1px solid var(--hair)',alignItems:'center'}}>
            <div>
              <div style={{fontFamily:'var(--cond)',fontSize:16,fontWeight:600,color:'var(--txt-hi)',textTransform:'uppercase'}}>{nm}</div>
              <div className="tc" style={{fontFamily:'var(--mono)',fontSize:11,color:'var(--txt-low)',marginTop:2}}>{tc}</div>
            </div>
            <div className="tc" style={{fontFamily:'var(--mono)',fontSize:20,fontWeight:600,color:'var(--txt)'}}>{cd}</div>
          </div>
        ))}
      </div>

      <div style={{height:36,padding:'0 14px',display:'flex',alignItems:'center',justifyContent:'space-between',background:'var(--surface)',borderTop:'1px solid var(--hair)',fontFamily:'var(--cond)',fontSize:9,fontWeight:600,letterSpacing:'.14em',textTransform:'uppercase',color:'var(--txt-mid)'}}>
        <span>All cams ▸</span>
        <span style={{color:'var(--txt-low)'}}>read-only</span>
      </div>
    </div>
  </div>
);

const IpadTrackViewer = () => (
  <div className="ab" style={{background:'#050507'}}>
    <div className="vwr-mobile-bar">
      <span>LX · LIGHTING · MY VIEW</span>
      <span className="tc">01:23:45:12</span>
      <span style={{color:'var(--red)'}}>● ON AIR</span>
    </div>

    <div className="vwr-mobile">
      <div style={{padding:'22px 28px 22px',background:'var(--surface)',borderBottom:'1px solid var(--hair)'}}>
        <div style={{fontFamily:'var(--cond)',fontSize:11,fontWeight:700,letterSpacing:'.22em',textTransform:'uppercase',color:'var(--red)',display:'flex',alignItems:'center',gap:8,marginBottom:12}}>
          <Pip k="live" pulse/>Lighting · ON
        </div>
        <div style={{display:'grid',gridTemplateColumns:'auto 1fr auto',gap:18,alignItems:'center'}}>
          <TrackGlyph code="LX" size="md"/>
          <div>
            <div style={{fontFamily:'var(--cond)',fontSize:36,fontWeight:700,color:'var(--txt-hi)',textTransform:'uppercase',lineHeight:1}}>Verse wash · 60%</div>
            <div style={{fontFamily:'var(--sans)',fontSize:13,color:'var(--txt)',marginTop:8,maxWidth:'40ch',lineHeight:1.4}}>Warm wash, 60% intensity, hold through verse 2.</div>
          </div>
          <div style={{textAlign:'right'}}>
            <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',color:'var(--txt-mid)',textTransform:'uppercase'}}>Held for</div>
            <div className="tc" style={{fontFamily:'var(--mono)',fontSize:42,fontWeight:700,color:'var(--txt-hi)',lineHeight:1,marginTop:4}}>0:18</div>
          </div>
        </div>
      </div>

      <div style={{padding:'14px 28px',flex:1,overflow:'hidden'}}>
        <div style={{fontFamily:'var(--cond)',fontSize:11,fontWeight:700,letterSpacing:'.22em',textTransform:'uppercase',color:'var(--txt-mid)',marginBottom:12}}>My next cues</div>
        {[
          ['Chorus build',      'Build to full intensity',  '01:23:47:24','0:12', 12],
          ['Confetti / strobe', 'Pyro 03 trigger window',   '01:23:54:00','0:18', 18],
          ['Bridge wash',       'Cool blue, 80%',           '01:24:02:12','1:50', 110],
          ['Out wash',          'House to half',            '01:24:48:00','5:24', 324],
        ].map(([nm,ds,tc,cd,cdSec],i)=>{
          const urgent = cdSec <= 10;
          const showBar = cdSec <= 20;
          const fillPct = Math.max(0, Math.min(100, (20 - cdSec)/20 * 100));
          return (
            <div key={i} style={{display:'grid',gridTemplateColumns:'24px 1fr auto auto',gap:16,alignItems:'center',padding:'12px 0',borderBottom:'1px solid var(--hair)',position:'relative'}}>
              <div style={{fontFamily:'var(--mono)',fontSize:11,color:'var(--txt-low)'}}>+{i+1}</div>
              <div>
                <div style={{fontFamily:'var(--cond)',fontSize:22,fontWeight:600,color:'var(--txt-hi)',textTransform:'uppercase',lineHeight:1.05}}>{nm}</div>
                <div style={{fontFamily:'var(--sans)',fontSize:12,color:'var(--txt-mid)',marginTop:2}}>{ds}</div>
              </div>
              <div className="tc" style={{fontFamily:'var(--mono)',fontSize:12,color:'var(--txt-mid)'}}>{tc}</div>
              <div className="tc" style={{fontFamily:'var(--mono)',fontSize:24,fontWeight:600,color: urgent?'var(--red)':(showBar?'var(--amber)':'var(--txt)'),minWidth:74,textAlign:'right'}}>{cd}</div>
              {showBar && (
                <div style={{gridColumn:'1 / -1',height:3,background:'var(--hair)',position:'relative',marginTop:6,marginBottom:-4}}>
                  <div style={{position:'absolute',inset:'0 auto 0 0',width: fillPct+'%',background: urgent?'var(--red)':'var(--amber)'}}></div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  </div>
);

/* ════════════════════════════════════════════
   EDIT — planner (cue list + timeline + inspector)
   ════════════════════════════════════════════ */
/* ════════════════════════════════════════════
   NEW-TRACK MODAL — tracks have a FULL name (used in
   inspector, large headings) and a SHORT name (used
   in small labels, lane heads, badges).
   ════════════════════════════════════════════ */
const NewTrackModal = () => (
  <div className="ab" style={{background:'var(--bg)'}}>
    {/* dimmed editor underneath */}
    <div style={{position:'absolute',inset:0,opacity:0.35,filter:'blur(2px)',pointerEvents:'none'}}>
      <EditBoard/>
    </div>
    <div style={{position:'absolute',inset:0,background:'rgba(0,0,0,0.55)'}}></div>

    {/* modal */}
    <div style={{position:'absolute',top:'50%',left:'50%',transform:'translate(-50%,-50%)',width:520,background:'var(--surface)',border:'1px solid var(--hair3)',boxShadow:'0 30px 80px rgba(0,0,0,0.6)'}}>
      <div style={{padding:'18px 24px',borderBottom:'1px solid var(--hair2)',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <div style={{fontFamily:'var(--cond)',fontSize:14,fontWeight:700,letterSpacing:'0.06em',color:'var(--txt-hi)',textTransform:'uppercase'}}>New track</div>
        <div style={{fontFamily:'var(--cond)',fontSize:10,letterSpacing:'.18em',color:'var(--txt-mid)',textTransform:'uppercase'}}>Normal · non-camera</div>
      </div>

      <div style={{padding:'24px 24px 8px'}}>
        <div style={{marginBottom:18}}>
          <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--txt-mid)',marginBottom:6}}>Full name</div>
          <div style={{background:'var(--surface2)',border:'1px solid var(--amber)',padding:'12px 14px',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
            <span style={{fontFamily:'var(--cond)',fontSize:18,fontWeight:600,color:'var(--txt-hi)'}}>Lighting</span>
            <span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--txt-low)'}}>26/40</span>
          </div>
          <div style={{fontFamily:'var(--sans)',fontSize:11,color:'var(--txt-mid)',marginTop:6,fontStyle:'italic'}}>Used in headings, inspector, alerts.</div>
        </div>

        <div style={{marginBottom:18}}>
          <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--txt-mid)',marginBottom:6}}>Short name</div>
          <div style={{background:'var(--surface2)',border:'1px solid var(--hair2)',padding:'12px 14px',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
            <span style={{fontFamily:'var(--cond)',fontSize:18,fontWeight:700,color:'var(--txt-hi)',letterSpacing:'.05em'}}>LX</span>
            <span style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--txt-low)'}}>2/4</span>
          </div>
          <div style={{fontFamily:'var(--sans)',fontSize:11,color:'var(--txt-mid)',marginTop:6,fontStyle:'italic'}}>Used in lane heads, list rows, mobile chrome. Max 4 chars.</div>
        </div>

        {/* preview row */}
        <div style={{padding:'14px 16px',background:'var(--canvas)',border:'1px solid var(--hair)',marginBottom:8}}>
          <div style={{fontFamily:'var(--cond)',fontSize:9,fontWeight:700,letterSpacing:'.22em',textTransform:'uppercase',color:'var(--txt-mid)',marginBottom:10}}>Preview · how the label appears</div>
          <div style={{display:'flex',gap:18,alignItems:'center'}}>
            <div style={{flex:1}}>
              <div style={{fontFamily:'var(--cond)',fontSize:10,letterSpacing:'.18em',textTransform:'uppercase',color:'var(--txt-low)',marginBottom:4}}>Inspector · large</div>
              <div style={{fontFamily:'var(--cond)',fontSize:18,fontWeight:600,color:'var(--txt-hi)'}}>Lighting</div>
            </div>
            <div>
              <div style={{fontFamily:'var(--cond)',fontSize:10,letterSpacing:'.18em',textTransform:'uppercase',color:'var(--txt-low)',marginBottom:4}}>Timeline · small</div>
              <TrackGlyph code="LX" size="sm"/>
            </div>
            <div>
              <div style={{fontFamily:'var(--cond)',fontSize:10,letterSpacing:'.18em',textTransform:'uppercase',color:'var(--txt-low)',marginBottom:4}}>List · xs</div>
              <TrackGlyph code="LX" size="xs"/>
            </div>
          </div>
        </div>

        <div style={{marginBottom:8}}>
          <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--txt-mid)',marginBottom:6}}>Type</div>
          <div style={{display:'flex',gap:0,border:'1px solid var(--hair2)'}}>
            <div style={{flex:1,padding:'10px 14px',background:'var(--amber)',color:'#000',fontFamily:'var(--cond)',fontSize:11,fontWeight:700,letterSpacing:'.14em',textTransform:'uppercase',textAlign:'center'}}>Normal</div>
            <div style={{flex:1,padding:'10px 14px',background:'transparent',color:'var(--txt-mid)',fontFamily:'var(--cond)',fontSize:11,fontWeight:600,letterSpacing:'.14em',textTransform:'uppercase',textAlign:'center'}}>Camera</div>
          </div>
        </div>
      </div>

      <div style={{padding:'18px 24px',borderTop:'1px solid var(--hair2)',display:'flex',gap:10,justifyContent:'flex-end'}}>
        <button style={{padding:'9px 16px',background:'transparent',color:'var(--txt-mid)',border:'1px solid var(--hair2)',fontFamily:'var(--cond)',fontSize:11,fontWeight:600,letterSpacing:'.12em',textTransform:'uppercase',cursor:'pointer'}}>Cancel</button>
        <button style={{padding:'9px 18px',background:'var(--amber)',color:'#000',border:'none',fontFamily:'var(--cond)',fontSize:11,fontWeight:700,letterSpacing:'.14em',textTransform:'uppercase',cursor:'pointer'}}>Create track</button>
      </div>
    </div>
  </div>
);

const EditBoard = () => {
  /* CUE LIST DATA — order matters (TC sorted) */
  const cues = [
    {n:12, type:'cam', cam:3, tc:'01:23:43:00', nm:'Mid · drummer',         ds:'Establish drummer through fill',     du:'0:12'},
    {n:13, type:'norm', trk:'AUD', tc:'01:23:43:00', nm:'Bed 03 — instrumental', ds:'Bring back instrumental stem',   du:'0:24'},
    {n:14, type:'norm', trk:'LX',  tc:'01:23:43:18', nm:'Verse wash · 60%',      ds:'Warm wash, 60% intensity',       du:'0:06'},
    {n:15, type:'cam', cam:1, tc:'01:23:43:24', nm:'Wide · drone over',     ds:'Drone sweep stage → audience',       du:'0:06'},
    {n:16, type:'norm', trk:'VID', tc:'01:23:44:18', nm:'IMAG · live feed', ds:'LED side panels live-feed',           du:'0:18'},
    {n:17, type:'cam', cam:2, tc:'01:23:45:00', nm:'Wide pull · stage right', ds:'Hold wide thru verse 2. Punch on downbeat.', du:'0:12', state:'active'},
    {n:18, type:'cam', cam:4, tc:'01:23:47:24', nm:'Close · vocal',         ds:'Tight on lead vocal',                 du:'0:08', state:'warn'},
    {n:19, type:'norm', trk:'LX',  tc:'01:23:47:24', nm:'Chorus build',     ds:'Build to full intensity',            du:'0:00'},
    {n:20, type:'norm', trk:'AUD', tc:'01:23:48:08', nm:'Stem swap → vocals', ds:'Vocal stem dominant',              du:'0:22'},
    {n:21, type:'cam', cam:1, tc:'01:23:54:00', nm:'Wide · drone over',     ds:'Aerial sweep',                        du:'0:00'},
    {n:22, type:'norm', trk:'LX',  tc:'01:23:54:00', nm:'Confetti / strobe', ds:'Pyro 03 trigger window',             du:'0:11'},
    {n:23, type:'norm', trk:'VID', tc:'01:23:56:18', nm:'Lyric plate "Velocity"', ds:'Title card overlay',           du:'0:00'},
    {n:24, type:'cam', cam:3, tc:'01:24:02:12', nm:'Mid · drummer',         ds:'Wide → mid push',                    du:'0:18'},
  ];

  return (
    <div className="ab" style={{background:'var(--bg)'}}>
      <div className="statusbar edit-statusbar">
        <div className="sb-cell"><strong>Project</strong><span className="sb-val">Arena Tour 2026</span></div>
        <div className="sb-cell"><Pip k="ok"/><strong>Saved</strong><span className="sb-val" style={{color:'var(--txt-mid)'}}>2s ago · cloud</span></div>
        <div className="sb-cell"><strong>Sharing</strong><span className="sb-val">4 peers</span></div>
        <div className="sb-cell grow"></div>
        <div className="sb-cell"><Chip k="amber">EDIT MODE</Chip></div>
        <div className="sb-cell right" style={{padding:0}}>
          <button style={{height:'100%',padding:'0 18px',background:'var(--red)',color:'#fff',border:'none',fontFamily:'var(--cond)',fontSize:12,fontWeight:700,letterSpacing:'.16em',textTransform:'uppercase',cursor:'pointer',display:'flex',alignItems:'center',gap:8}}>
            <Pip k="live"/> Go Live
          </button>
        </div>
      </div>
      <div className="mode-banner edit"></div>

      <div className="edit-main">
        <Rail active="seq"/>

        {/* sequences panel */}
        <div className="seq-panel">
          <div className="seq-head">
            <div className="title">Sequences · 12</div>
            <button className="add">+ Add</button>
          </div>
          <div className="seq-list">
            {SHOW.sequences.map(s => (
              <div className={`seq-item ${s.state==='now'?'active':''}`} key={s.n}>
                <div className="num">{String(s.n).padStart(2,'0')}</div>
                <div className="nm">{s.nm}</div>
                <div className="dur tc">{s.dur}</div>
              </div>
            ))}
          </div>
        </div>

        {/* center */}
        <div className="edit-center">
          <div className="edit-tabs">
            <button className="edit-tab active">List <span className="count">84</span></button>
            <button className="edit-tab">Waterfall</button>
            <button className="edit-tab">Video</button>
            <button className="edit-tab">Notes <span className="count">3</span></button>
            <div className="edit-tab-spacer"></div>
            <div className="edit-tools">
              <button className="edit-tool" title="Filter cues"><IconFilt/></button>
              <button className="edit-tool" title="Import / export"><IconImp/></button>
              <button className="edit-tool" title="Settings"><IconSet/></button>
            </div>
          </div>

          {/* cue list */}
          <div className="cue-table">
            <div className="ct-head">
              <span>#</span><span>Track</span><span>Timecode</span><span>Cue</span><span>Description</span><span>Type</span><span>To next</span><span></span>
            </div>
            <div className="ct-rows">
              {cues.map(c=>(
                <div className={`ct-row ${c.state||''}`} key={c.n}>
                  <span className="ix">{c.n}</span>
                  <span>
                    {c.type==='cam'
                      ? <CamBadge n={c.cam} size="xs"/>
                      : <TrackGlyph code={c.trk} size="xs"/>}
                  </span>
                  <span className="tc">{c.tc}</span>
                  <span className="nm">{c.nm}</span>
                  <span className="ds">{c.ds}</span>
                  <span className="tr">{c.type==='cam'?'Camera':'Normal'}</span>
                  <span className="du tc">{c.du}</span>
                  <span className="x">×</span>
                </div>
              ))}
            </div>
          </div>

          {/* TIMELINE */}
          <div className="timeline">
            <div className="tl-toolbar">
              <button className="tl-btn" title="Restart (R)"><IconRewind/></button>
              <button className="tl-btn" title="Play (Space)"><IconPlay/></button>
              <button className="tl-btn" title="Stop"><IconStop/></button>
              <span className="sep"></span>
              <span className="tl-tc tc">01:23:45:12</span>
              <span className="sep"></span>
              <span>Seq 04 · Velocity · 4:32</span>
              <div className="grow"></div>
              <button className="tl-btn wide"><span className="plus">＋</span>Cue</button>
              <button className="tl-btn wide"><span className="plus">＋</span>Marker</button>
              <span className="sep"></span>
              <button className="tl-btn" title="Zoom out">−</button>
              <button className="tl-btn" title="Zoom in">+</button>
              <button className="tl-btn" title="Snap"><span style={{fontSize:13,lineHeight:1}}>⦿</span></button>
            </div>

            <div className="tl-ruler">
              {['01:23:40','01:23:45','01:23:50','01:23:55','01:24:00','01:24:05','01:24:10','01:24:15'].map((t,i)=>(
                <span key={t} className="tl-tick" style={{left:`${i*12.5}%`}}>{t}</span>
              ))}
            </div>

            <div className="tl-lanes">
              <div className="tl-playhead" style={{left:'13%'}}></div>

              <TimelineCamLane/>

              {/* AUDIO — single audio file per sequence, waveform spans full duration */}
              <div className="tl-lane">
                <div className="tl-lane-head"><TrackGlyph code="AUD" size="xs"/><span>Audio</span></div>
                <div className="tl-lane-body">
                  <div className="tl-cue aud" style={{left:'0%', width:'100%', top:4, bottom:4}}>
                    <span className="aud-lbl">velocity_master_v3.wav · 4:32</span>
                    <span className="aud-wave">
                      {wfPattern(160, 7, 0.55).map((v,i)=>(<i key={i} style={{height: Math.max(2, v*26)}}/>))}
                    </span>
                  </div>
                </div>
              </div>

              {/* LIGHTING — cues connect, no gaps */}
              <div className="tl-lane">
                <div className="tl-lane-head"><TrackGlyph code="LX" size="xs"/><span>Lighting</span></div>
                <div className="tl-lane-body">
                  {LX_CUES.map((c,i)=>(
                    <div className="tl-cue norm" key={i} style={{left:c.l,width:c.w}}>{c.nm}</div>
                  ))}
                  <div className="tl-cue marker" style={{left:'37%'}}>▼ Pyro 03</div>
                </div>
              </div>

              {/* VIDEO — cues connect */}
              <div className="tl-lane">
                <div className="tl-lane-head"><TrackGlyph code="VID" size="xs"/><span>Video</span></div>
                <div className="tl-lane-body">
                  {VID_CUES.map((c,i)=>(
                    <div className="tl-cue norm" key={i} style={{left:c.l,width:c.w}}>{c.nm}</div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* detail panel — cue inspector */}
        <div className="detail-panel">
          <div className="dp-head">
            <div className="dp-eyebrow">Cue 17 · cameras</div>
            <div style={{display:'flex',alignItems:'center',gap:14,marginTop:4}}>
              <CamBadge n={2} size="md"/>
              <div>
                <div className="dp-name">Wide pull</div>
                <div style={{fontFamily:'var(--cond)',fontSize:14,color:'var(--txt-mid)',textTransform:'uppercase',letterSpacing:'0.04em'}}>· stage right</div>
              </div>
            </div>
          </div>
          <div className="dp-section">
            <div className="dp-row"><span className="lab">Timecode</span><span className="val">01:23:45:00</span></div>
            <div className="dp-row"><span className="lab">Camera</span><span className="val" style={{color:camCol(2)}}>02</span></div>
            <div className="dp-row"><span className="lab">Duration</span><span className="val">2.24s</span></div>
            <div className="dp-row"><span className="lab">To next</span><span className="val" style={{color:'var(--amber)'}}>0:12</span></div>
            <div className="dp-row"><span className="lab">Track</span><span className="val sans">Cameras</span></div>
          </div>
          <div className="dp-section">
            <div className="dp-eyebrow">Notes</div>
            <div className="dp-notes">
              Hold wide through verse 2. On downbeat punch to CAM 04 close.{' '}
              <span style={{color:'var(--amber)'}}>Watch for confetti drop on chorus — Pyro 03 cue at 01:23:54:00.</span>
            </div>
          </div>
          <div className="dp-section">
            <div className="dp-eyebrow">Linked cues</div>
            <div style={{display:'flex',flexDirection:'column',gap:6,marginTop:8}}>
              <div style={{display:'flex',alignItems:'center',gap:10,padding:'8px 10px',background:'var(--surface2)',border:'1px solid var(--hair)'}}>
                <TrackGlyph code="LX" size="xs"/>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:12,color:'var(--txt-hi)',fontWeight:600}}>Verse wash · 60%</div>
                  <div style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--txt-mid)'}}>01:23:43:18 · -1.06s</div>
                </div>
              </div>
              <div style={{display:'flex',alignItems:'center',gap:10,padding:'8px 10px',background:'var(--surface2)',border:'1px solid var(--hair)'}}>
                <TrackGlyph code="AUD" size="xs"/>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:12,color:'var(--txt-hi)',fontWeight:600}}>Bed 03 — instrumental</div>
                  <div style={{fontFamily:'var(--mono)',fontSize:10,color:'var(--txt-mid)'}}>01:23:43:00 · -2.00s</div>
                </div>
              </div>
            </div>
          </div>
          <div className="dp-section" style={{borderBottom:'none',marginTop:'auto'}}>
            <div style={{display:'flex',gap:8}}>
              <button style={{flex:1,padding:'9px 12px',background:'var(--surface2)',border:'1px solid var(--hair2)',color:'var(--txt)',fontFamily:'var(--cond)',fontSize:11,fontWeight:600,letterSpacing:'.12em',textTransform:'uppercase',cursor:'pointer'}}>Duplicate</button>
              <button style={{flex:1,padding:'9px 12px',background:'var(--amber)',border:'1px solid var(--amber)',color:'#000',fontFamily:'var(--cond)',fontSize:11,fontWeight:700,letterSpacing:'.12em',textTransform:'uppercase',cursor:'pointer'}}>Save cue</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ════════════════════════════════════════════
   TYPE / COMPONENTS BOARD
   ════════════════════════════════════════════ */
const ComponentsBoard = () => (
  <div className="ab cb">
    <div>
      <h2>Typography</h2>
      <div className="type-row">
        <div className="tc" style={{fontFamily:'var(--mono)',fontSize:84,fontWeight:700,color:'var(--txt-hi)',lineHeight:1,letterSpacing:'-0.02em'}}>01:23:45:12</div>
        <div className="type-spec">JetBrains Mono · 700 · 84/80 · -2% tracking · tabular-nums</div>
        <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--amber)',marginTop:8}}>TC · COUNTDOWN</div>
      </div>

      <div className="type-row">
        <div style={{fontFamily:'var(--cond)',fontSize:48,fontWeight:700,color:'var(--txt-hi)',letterSpacing:'-0.01em',textTransform:'uppercase',lineHeight:1}}>Close · vocal</div>
        <div className="type-spec">IBM Plex Sans Condensed · 700 · 48/48 · uppercase</div>
        <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--amber)',marginTop:8}}>NEXT-CUE HERO NAME</div>
      </div>

      <div className="type-row">
        <div style={{fontFamily:'var(--cond)',fontSize:14,fontWeight:600,color:'var(--txt-hi)',letterSpacing:'0.12em',textTransform:'uppercase'}}>Track · cameras · cue 17 / 84</div>
        <div className="type-spec">IBM Plex Sans Condensed · 600 · 14 · 12% tracking · uppercase</div>
        <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--amber)',marginTop:8}}>LABELS · EYEBROWS · CHIPS</div>
      </div>

      <div className="type-row">
        <div style={{fontFamily:'var(--sans)',fontSize:16,color:'var(--txt)',lineHeight:1.5,maxWidth:'56ch'}}>
          Hold wide through verse 2. On downbeat punch to CAM 04 close. Watch for confetti drop on chorus — Pyro 03 cue.
        </div>
        <div className="type-spec">IBM Plex Sans · 400 · 16/24</div>
        <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--amber)',marginTop:8}}>CUE DESCRIPTIONS · BODY</div>
      </div>

      <h2 style={{marginTop:28}}>Camera badges · numbered, color-coded</h2>
      <div style={{display:'flex',alignItems:'flex-end',gap:18,marginBottom:14,flexWrap:'wrap'}}>
        <CamBadge n={1} size="lg"/>
        <CamBadge n={2} size="md"/>
        <CamBadge n={3} size="sm"/>
        <CamBadge n={4} size="xs"/>
      </div>
      <div className="type-spec" style={{marginBottom:18}}>
        JetBrains Mono 800 · -4% tracking · zero-padded. xs / sm / md / lg / xl sizes.
      </div>
      <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
        {[1,2,3,4,5,6,7,8].map(n=>(
          <CamBadge key={n} n={n} size="sm"/>
        ))}
      </div>
      <div className="type-spec" style={{marginTop:8}}>
        Camera palette — vivid, distinct hues. Never used for anything that isn't a camera.
      </div>

      <h2 style={{marginTop:28}}>Normal-track glyphs · same footprint as cameras</h2>
      <div style={{display:'flex',alignItems:'flex-end',gap:18,marginBottom:14,flexWrap:'wrap'}}>
        <TrackGlyph code="AUD" size="lg"/>
        <TrackGlyph code="LX" size="md"/>
        <TrackGlyph code="VID" size="sm"/>
        <TrackGlyph code="FX" size="xs"/>
      </div>
      <div className="type-spec" style={{marginBottom:14}}>
        Hairline border + condensed caps. Identical dimensions to cam badges — no chaos.
      </div>
      <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
        <TrackGlyph code="AUD" size="sm"/>
        <TrackGlyph code="LX"  size="sm"/>
        <TrackGlyph code="VID" size="sm"/>
        <TrackGlyph code="FX"  size="sm"/>
        <TrackGlyph code="MIDI" size="sm"/>
      </div>
      <div className="type-spec" style={{marginTop:8}}>
        No bright color. Differentiated by typography alone.
      </div>
    </div>

    <div>
      <h2>Color · state-only</h2>
      <div style={{marginBottom:24}}>
        <div className="tone-row">
          {[
            ['#050507','BG','dark','050507'],
            ['#0a0a0d','CANVAS','dark','0a0a0d'],
            ['#111116','SURFACE','dark','111116'],
            ['#16161c','SURF 2','dark','16161c'],
            ['#1d1d24','SURF 3','dark','1d1d24'],
          ].map(([c,n,k,h])=>(
            <div className={`tone ${k}`} key={n} style={{background:c,border:'1px solid var(--hair)'}}>
              <div className="nm">{n}</div>
              <div>{h}</div>
            </div>
          ))}
        </div>
        <div style={{fontSize:11,color:'var(--txt-mid)',marginTop:4,fontFamily:'var(--mono)'}}>Surfaces — five steps, cool-black. No pure black.</div>
      </div>

      <div style={{marginBottom:24}}>
        <div className="tone-row">
          {[
            ['#f0a838','AMBER','light','Standby · accent'],
            ['#ff2848','TALLY','dark','● On air'],
            ['#18d986','LOCK','light','Sync · safe'],
          ].map(([c,n,k,h])=>(
            <div className={`tone ${k}`} key={n} style={{background:c}}>
              <div className="nm">{n}</div>
              <div>{h}</div>
            </div>
          ))}
        </div>
        <div style={{fontSize:11,color:'var(--txt-mid)',marginTop:4,fontFamily:'var(--mono)'}}>System: amber = standby/next, tally red = on air, green = locked.</div>
      </div>

      <h2>Audio waveform</h2>
      <div style={{position:'relative',height:54,background:'var(--surface2)',border:'1px solid var(--hair2)',marginBottom:8,padding:'0',display:'flex',alignItems:'stretch'}}>
        <div style={{position:'absolute',top:3,left:8,fontFamily:'var(--cond)',fontSize:10,fontWeight:600,color:'var(--txt)',textTransform:'uppercase',letterSpacing:'.04em',zIndex:2}}>
          Bed 03 — instrumental
        </div>
        <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',padding:'18px 6px 4px',gap:1}}>
          {wfPattern(120, 7, 0.5).map((v,i)=>(<i key={i} style={{display:'block',width:2,background:'var(--txt-mid)',opacity:0.6,height: Math.max(2, v*28)}}/>))}
        </div>
      </div>
      <div className="type-spec" style={{marginBottom:24}}>
        Audio cues in the timeline render their waveform inline. Label floats top-left.
      </div>

      <h2>Components</h2>
      <div style={{display:'flex',flexDirection:'column',gap:18}}>
        <div>
          <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--txt-mid)',marginBottom:10}}>Chips</div>
          <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
            <Chip k="red">● ON AIR</Chip>
            <Chip k="amber">STANDBY</Chip>
            <Chip k="green">LOCKED</Chip>
            <Chip k="ghost">CUE 17 / 84</Chip>
          </div>
        </div>

        <div>
          <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--txt-mid)',marginBottom:10}}>Trust pips & signal</div>
          <div style={{display:'flex',gap:24,alignItems:'center',flexWrap:'wrap'}}>
            <span style={{display:'flex',alignItems:'center',gap:8}}><Pip k="ok"/><span style={{fontFamily:'var(--cond)',fontSize:11,letterSpacing:'.12em',textTransform:'uppercase'}}>OK</span></span>
            <span style={{display:'flex',alignItems:'center',gap:8}}><Pip k="warn"/><span style={{fontFamily:'var(--cond)',fontSize:11,letterSpacing:'.12em',textTransform:'uppercase'}}>STBY</span></span>
            <span style={{display:'flex',alignItems:'center',gap:8}}><Pip k="live" pulse/><span style={{fontFamily:'var(--cond)',fontSize:11,letterSpacing:'.12em',textTransform:'uppercase'}}>LIVE</span></span>
            <span style={{display:'flex',alignItems:'center',gap:8}}><Pip k="idle"/><span style={{fontFamily:'var(--cond)',fontSize:11,letterSpacing:'.12em',textTransform:'uppercase'}}>IDLE</span></span>
            <span style={{display:'flex',alignItems:'center',gap:8}}><Bars k="ok"/><span style={{fontFamily:'var(--cond)',fontSize:11,letterSpacing:'.12em',textTransform:'uppercase'}}>LOCKED</span></span>
            <span style={{display:'flex',alignItems:'center',gap:8}}><Bars k="warn"/><span style={{fontFamily:'var(--cond)',fontSize:11,letterSpacing:'.12em',textTransform:'uppercase'}}>DRIFT</span></span>
            <span style={{display:'flex',alignItems:'center',gap:8}}><Bars k="bad"/><span style={{fontFamily:'var(--cond)',fontSize:11,letterSpacing:'.12em',textTransform:'uppercase'}}>LOST</span></span>
          </div>
        </div>

        <div>
          <div style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.2em',textTransform:'uppercase',color:'var(--txt-mid)',marginBottom:10}}>Buttons</div>
          <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
            <button style={{padding:'9px 16px',background:'var(--red)',color:'#fff',border:'none',fontFamily:'var(--cond)',fontSize:11,fontWeight:700,letterSpacing:'.16em',textTransform:'uppercase',cursor:'pointer'}}>● Go Live</button>
            <button style={{padding:'9px 16px',background:'var(--amber)',color:'#000',border:'none',fontFamily:'var(--cond)',fontSize:11,fontWeight:700,letterSpacing:'.12em',textTransform:'uppercase',cursor:'pointer'}}>Save</button>
            <button style={{padding:'9px 16px',background:'var(--surface2)',color:'var(--txt)',border:'1px solid var(--hair2)',fontFamily:'var(--cond)',fontSize:11,fontWeight:600,letterSpacing:'.12em',textTransform:'uppercase',cursor:'pointer'}}>＋ Cue</button>
            <button style={{padding:'9px 16px',background:'transparent',color:'var(--txt-mid)',border:'1px solid var(--hair2)',fontFamily:'var(--cond)',fontSize:11,fontWeight:600,letterSpacing:'.12em',textTransform:'uppercase',cursor:'pointer'}}>Cancel</button>
          </div>
        </div>
      </div>
    </div>
  </div>
);

/* ════════════════════════════════════════════
   RESPONSIVE HELPERS — shared by all tablet/phone viewers
   ════════════════════════════════════════════ */

/* small status bar shown atop every mobile viewer */
const MobileBar = ({left, mid='01:23:45', right='● ON AIR', rightColor='var(--red)'}) => (
  <div className="vwr-mobile-bar">
    <span>{left}</span>
    <span className="tc">{mid}</span>
    <span style={{color: rightColor}}>{right}</span>
  </div>
);

/* CAMERA-flavored on-air block (cam badge + held + cut-in) */
const MobileOnAirCam = ({cam, name, desc, held, cutIn, cutSec=12, badgeSize='lg', extra}) => {
  const urgent = cutSec <= 10;
  const fill = Math.max(0, Math.min(100, (20 - cutSec) / 20 * 100));
  return (
    <div className={`m-onair cam ${extra||''}`}
         style={{'--cam-col': camCol(cam), '--cam-bg': camBg(cam)}}>
      <div className="eyebrow"><Pip k="live" pulse/>On camera · CAM {String(cam).padStart(2,'0')}</div>
      <div className="row">
        <CamBadge n={cam} size={badgeSize}/>
        <div>
          <div className="nm">{name}</div>
          {desc && <div className="ds">{desc}</div>}
        </div>
      </div>
      <div className="metrics">
        <div className="metric">
          <div className="lbl">Held for</div>
          <div className="v tc lg">{held}</div>
        </div>
        <div className="metric right">
          <div className="lbl">Cut in</div>
          <div className="v tc xl">{cutIn}</div>
        </div>
      </div>
      <div className={`cut-bar ${urgent?'urgent':''}`}><div className="fill" style={{width: fill+'%'}}></div></div>
    </div>
  );
};

/* TRACK-flavored on-air block (normal/non-camera track) */
const MobileOnAirTrack = ({short, full, name, desc, held, extra}) => (
  <div className={`m-onair ${extra||''}`}>
    <div className="eyebrow"><Pip k="live" pulse/>{full} · ON</div>
    <div className="row">
      <TrackGlyph code={short} size="md"/>
      <div>
        <div className="nm">{name}</div>
        {desc && <div className="ds">{desc}</div>}
      </div>
    </div>
    <div className="metrics">
      <div className="metric">
        <div className="lbl">Held for</div>
        <div className="v tc lg">{held}</div>
      </div>
      <div className="metric right">
        <div className="lbl">Track</div>
        <div className="v tc lg" style={{fontFamily:'var(--cond)',fontSize:32,letterSpacing:'.04em'}}>{short}</div>
      </div>
    </div>
  </div>
);

/* Upcoming list — works for camera-op-main (no badges), camera-op-all (cam badges),
   or normal-track (track glyphs). pass tag=(q,i)=>JSX */
const MobileUpcoming = ({label, meta, items, tag, lg=false, extra}) => (
  <div className={`m-upcoming ${extra||''}`}>
    <div className="head">
      <span className="lbl">{label}</span>
      <span className="meta">{meta}</span>
    </div>
    {items.map((q,i)=>{
      const urgent = q.cdSec != null && q.cdSec <= 10;
      const showBar = q.cdSec != null && q.cdSec <= 20;
      const fill = q.cdSec != null ? Math.max(0, Math.min(100, (20 - q.cdSec) / 20 * 100)) : 0;
      return (
        <div className={`m-up-row ${lg?'lg':''} ${lg?'t-up-row':''}`} key={i}>
          {tag ? <div>{tag(q,i)}</div> : <div className="ix">+{i+1}</div>}
          <div>
            <div className="nm">{q.nm}</div>
            {q.ds && <div className="ds">{q.ds}</div>}
          </div>
          <div className={`cd ${urgent?'urgent':(showBar?'warn':'')}`}>{q.cd}</div>
          {showBar && (
            <div className={`urg-bar ${urgent?'urgent':''}`}>
              <div className="urg-fill" style={{width: fill+'%'}}></div>
            </div>
          )}
        </div>
      );
    })}
  </div>
);

/* Compact peripheral setlist for mobile */
const MobileSetlist = () => (
  <div className="m-setlist">
    <div className="head">
      <span>Setlist</span>
      <span style={{fontFamily:'var(--mono)',fontSize:9,color:'var(--txt-low)',letterSpacing:0,textTransform:'none'}}>3 / 12 · 18:42 in</span>
    </div>
    {SHOW.sequences.slice(2, 8).map(s => (
      <div className={`item ${s.state||''}`} key={s.n}>
        <span className="ix">{String(s.n).padStart(2,'0')}</span>
        <span className="nm">{s.nm}</span>
        <span className="dur">{s.dur}</span>
      </div>
    ))}
  </div>
);

/* foot strip */
const MobileFoot = ({left, right='read-only'}) => (
  <div className="m-foot">
    <span>{left}</span>
    <span style={{color:'var(--txt-low)'}}>{right}</span>
  </div>
);

/* ════════════════════════════════════════════
   DIRECTOR / SHOW-CALLER — all tracks, all cues
   ════════════════════════════════════════════ */
const MobileDirector = ({tablet=false}) => (
  <div className="ab" style={{background:'#050507'}}>
    <MobileBar left="DIRECTOR · ALL TRACKS"/>
    <div className="vwr-mobile">
      <div className={`m-onair cam ${tablet?'t-onair':''}`} style={{'--cam-col':camCol(2),'--cam-bg':camBg(2)}}>
        <div className="eyebrow"><Pip k="live" pulse/>On air · cue 17 / 84</div>
        <div className="row">
          <CamBadge n={2} size={tablet?'lg':'md'}/>
          <div>
            <div className="nm">Wide pull · SR</div>
            <div className="ds">Seq 04 · Velocity (opener)</div>
          </div>
        </div>
        <div className="metrics">
          <div className="metric">
            <div className="lbl">On air</div>
            <div className="v tc lg">0:42</div>
          </div>
          <div className="metric right">
            <div className="lbl">Next cue · in</div>
            <div className="v tc xl">0:12</div>
          </div>
        </div>
        <div className="cut-bar"><div className="fill" style={{width:'40%'}}></div></div>
      </div>

      <MobileUpcoming
        label="Next · 5 cues"
        meta="across all tracks"
        lg={tablet}
        tag={(q)=> q.cam ? <CamBadge n={q.cam} size="sm"/> : <TrackGlyph code={q.trk} size="sm"/>}
        items={[
          {cam:4, nm:'Close · vocal',          ds:'Tight on lead',          cd:'0:12', cdSec:12},
          {trk:'LX', nm:'Chorus build',        ds:'Full intensity',         cd:'0:12', cdSec:12},
          {cam:1, nm:'Wide · drone',           ds:'Aerial sweep',           cd:'0:18', cdSec:18},
          {trk:'VID', nm:'Lyric plate',        ds:'"Velocity" overlay',     cd:'0:24', cdSec:24},
          {cam:3, nm:'Mid · drummer',          ds:'Wide → mid push',        cd:'1:50', cdSec:110},
        ]}
      />

      <MobileSetlist/>
      <MobileFoot left="● Director · seq 04" right="~ 1:42 left"/>
    </div>
  </div>
);

/* ════════════════════════════════════════════
   CAMERA OP — main (only my cuts)
   ════════════════════════════════════════════ */
const MobileCamOpMain = ({tablet=false}) => (
  <div className="ab" style={{background:'#050507'}}>
    <MobileBar left="CAM 02 · MY VIEW"/>
    <div className="vwr-mobile">
      <MobileOnAirCam
        cam={2}
        name="Wide pull · SR"
        desc="Hold wide thru verse 2. Punch on downbeat."
        held="0:42"
        cutIn="0:12"
        cutSec={12}
        badgeSize={tablet?'lg':'md'}
        extra={tablet?'t-onair':''}
      />
      <MobileUpcoming
        label="My next shots"
        meta="CAM 02 · seq 04"
        lg={tablet}
        tag={(q,i)=> <span style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:600,color:'var(--txt-mid)',letterSpacing:'.12em',textTransform:'uppercase'}}>+{i+1}</span>}
        items={[
          {nm:'Close · guitar SR',  ds:'Tight on guitar solo',  cd:'2:42', cdSec:162},
          {nm:'Wide pull · SR',      ds:'Re-establish post-bridge', cd:'3:42', cdSec:222},
          {nm:'Mid · guitar',        ds:'Mid lock thru chorus',  cd:'5:18', cdSec:318},
        ]}
      />
      <MobileFoot left="All cams ▸"/>
    </div>
  </div>
);

/* ════════════════════════════════════════════
   CAMERA OP — all cams (alt view)
   ════════════════════════════════════════════ */
const MobileCamOpAll = ({tablet=false}) => (
  <div className="ab" style={{background:'#050507'}}>
    <MobileBar left="CAM 02 · ALL CAMS"/>
    <div className="vwr-mobile">
      <MobileOnAirCam
        cam={2}
        name="Wide pull · SR"
        desc="My current shot."
        held="0:42"
        cutIn="0:12"
        cutSec={12}
        badgeSize={tablet?'lg':'md'}
        extra={tablet?'t-onair':''}
      />
      <MobileUpcoming
        label="All cameras · upcoming"
        meta="5 next cuts"
        lg={tablet}
        tag={(q)=> <CamBadge n={q.cam} size={tablet?'md':'sm'}/>}
        items={[
          {cam:4, nm:'Close · vocal',     ds:'Tight on lead',    cd:'0:12', cdSec:12},
          {cam:1, nm:'Wide · drone',      ds:'Aerial sweep',     cd:'0:18', cdSec:18},
          {cam:3, nm:'Mid · drummer',     ds:'Wide → mid',       cd:'1:50', cdSec:110},
          {cam:5, nm:'Wide · audience',   ds:'Crowd reaction',   cd:'2:08', cdSec:128},
          {cam:4, nm:'Close · guitar SR', ds:'Solo tight',       cd:'2:42', cdSec:162},
        ]}
      />
      <MobileFoot left="◂ My cam only"/>
    </div>
  </div>
);

/* ════════════════════════════════════════════
   NORMAL-TRACK VIEWER — mobile + tablet
   ════════════════════════════════════════════ */
const MobileTrackViewer = ({tablet=false, track={short:'LX', full:'Lighting'}}) => (
  <div className="ab" style={{background:'#050507'}}>
    <MobileBar left={`${track.short} · ${track.full.toUpperCase()}`}/>
    <div className="vwr-mobile">
      <MobileOnAirTrack
        short={track.short}
        full={track.full}
        name="Verse wash · 60%"
        desc="Warm wash, 60% intensity, hold through verse 2."
        held="0:18"
        extra={tablet?'t-onair':''}
      />
      <MobileUpcoming
        label={`My next cues · ${track.full}`}
        meta={`${track.short} · seq 04`}
        lg={tablet}
        tag={()=> <TrackGlyph code={track.short} size="sm"/>}
        items={[
          {nm:'Chorus build',      ds:'Build to full intensity',   cd:'0:12', cdSec:12},
          {nm:'Confetti / strobe', ds:'Pyro 03 trigger window',    cd:'0:18', cdSec:18},
          {nm:'Bridge wash',       ds:'Cool blue, 80%',            cd:'1:50', cdSec:110},
          {nm:'Out wash',          ds:'House to half',             cd:'5:24', cdSec:324},
        ]}
      />
      <MobileFoot left={`${track.short} · seq 04`} right="~ 1:42 left"/>
    </div>
  </div>
);

/* ════════════════════════════════════════════
   TC VIEWER — responsive
   ════════════════════════════════════════════ */
const MobileTC = ({tablet=false, landscape=false}) => (
  <div className="ab" style={{background:'#050507'}}>
    <MobileBar
      left={<span style={{display:'flex',alignItems:'center',gap:6}}><Pip k="ok" pulse/>LTC · LOCKSTEP</span>}
      mid="25.000 FPS"
      right="● LOCKED"
      rightColor="var(--green)"
    />
    <div className={`tcview-mobile ${landscape?'tcview-tablet-landscape':''}`}>
      <div className="tcv-body">
        <div className={`tcv ${landscape?'':'tc'}`}
             style={!landscape ? {fontSize: tablet?'clamp(120px,20vw,180px)':'clamp(48px,18vw,84px)'} : {}}>
          01:23:45:12
        </div>
      </div>
      <div style={{padding:'18px 24px',borderTop:'1px solid var(--hair)',display:'grid',gridTemplateColumns:'1fr 1fr',gap:18}}>
        <div>
          <div style={{fontFamily:'var(--cond)',fontSize:9,fontWeight:700,letterSpacing:'.22em',textTransform:'uppercase',color:'var(--txt-mid)',marginBottom:4}}>Sequence</div>
          <div style={{fontFamily:'var(--cond)',fontSize: tablet?16:14,fontWeight:600,color:'var(--txt-hi)',textTransform:'uppercase'}}>04 · Velocity</div>
        </div>
        <div style={{textAlign:'right'}}>
          <div style={{fontFamily:'var(--cond)',fontSize:9,fontWeight:700,letterSpacing:'.22em',textTransform:'uppercase',color:'var(--txt-mid)',marginBottom:4}}>Next in</div>
          <div style={{fontFamily:'var(--mono)',fontSize: tablet?20:16,fontWeight:700,color:'var(--amber)',letterSpacing:0}}>0:12 · close · vocal</div>
        </div>
      </div>
    </div>
  </div>
);

/* ════════════════════════════════════════════
   EDITOR — tablet landscape, simplified
   ════════════════════════════════════════════ */
const TabletEditor = () => {
  const cues = [
    {n:14, type:'norm', trk:'LX',  tc:'01:23:43:18', nm:'Verse wash · 60%',       du:'0:06'},
    {n:15, type:'cam', cam:1,      tc:'01:23:43:24', nm:'Wide · drone over',      du:'0:06'},
    {n:16, type:'norm', trk:'VID', tc:'01:23:44:18', nm:'IMAG · live feed',       du:'0:18'},
    {n:17, type:'cam', cam:2,      tc:'01:23:45:00', nm:'Wide pull · SR',         du:'0:12', state:'active'},
    {n:18, type:'cam', cam:4,      tc:'01:23:47:24', nm:'Close · vocal',          du:'0:08', state:'warn'},
    {n:19, type:'norm', trk:'LX',  tc:'01:23:47:24', nm:'Chorus build',           du:'0:00'},
    {n:20, type:'cam', cam:1,      tc:'01:23:54:00', nm:'Wide · drone',           du:'0:00'},
    {n:21, type:'norm', trk:'LX',  tc:'01:23:54:00', nm:'Confetti / strobe',      du:'0:11'},
    {n:22, type:'cam', cam:3,      tc:'01:24:02:12', nm:'Mid · drummer',          du:'0:18'},
  ];
  return (
    <div className="ab" style={{background:'var(--bg)'}}>
      {/* compact statusbar */}
      <div className="statusbar edit-statusbar" style={{height:32}}>
        <div className="sb-cell"><strong>Arena Tour</strong></div>
        <div className="sb-cell"><Pip k="ok"/><span className="sb-val">Saved</span></div>
        <div className="sb-cell grow"></div>
        <div className="sb-cell"><Chip k="amber">EDIT</Chip></div>
        <div className="sb-cell right" style={{padding:0}}>
          <button style={{height:'100%',padding:'0 14px',background:'var(--red)',color:'#fff',border:'none',fontFamily:'var(--cond)',fontSize:11,fontWeight:700,letterSpacing:'.14em',textTransform:'uppercase',cursor:'pointer',display:'flex',alignItems:'center',gap:6}}>
            <Pip k="live"/> Go Live
          </button>
        </div>
      </div>
      <div className="mode-banner edit"></div>

      <div className="editor-tablet">
        <div className="et-main">
          {/* sequences */}
          <div className="et-seq">
            <div style={{padding:'10px 14px',borderBottom:'1px solid var(--hair)',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <span style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.16em',textTransform:'uppercase',color:'var(--txt-hi)'}}>Seq · 12</span>
              <span style={{fontFamily:'var(--cond)',fontSize:11,color:'var(--amber)'}}>+ Add</span>
            </div>
            {SHOW.sequences.map(s => (
              <div className={`seq-item ${s.state==='now'?'active':''}`} key={s.n}>
                <div className="num">{String(s.n).padStart(2,'0')}</div>
                <div className="nm">{s.nm}</div>
                <div className="dur tc">{s.dur}</div>
              </div>
            ))}
          </div>

          {/* center */}
          <div style={{flex:1,display:'flex',flexDirection:'column',minWidth:0}}>
            <div className="edit-tabs" style={{height:34}}>
              <button className="edit-tab active">List <span className="count">84</span></button>
              <button className="edit-tab">Waterfall</button>
              <button className="edit-tab">Notes</button>
              <div className="edit-tab-spacer"></div>
              <div className="edit-tools">
                <button className="edit-tool"><IconFilt/></button>
                <button className="edit-tool"><IconImp/></button>
                <button className="edit-tool"><IconSet/></button>
              </div>
            </div>

            <div className="cue-table">
              <div className="ct-head" style={{gridTemplateColumns:'34px 28px 92px 1fr 60px 60px'}}>
                <span>#</span><span></span><span>TC</span><span>Cue</span><span>Type</span><span>To next</span>
              </div>
              <div className="ct-rows">
                {cues.map(c=>(
                  <div className={`ct-row ${c.state||''}`} key={c.n} style={{gridTemplateColumns:'34px 28px 92px 1fr 60px 60px',height:34}}>
                    <span className="ix">{c.n}</span>
                    <span>{c.type==='cam'?<CamBadge n={c.cam} size="xs"/>:<TrackGlyph code={c.trk} size="xs"/>}</span>
                    <span className="tc">{c.tc}</span>
                    <span className="nm">{c.nm}</span>
                    <span className="tr">{c.type==='cam'?'Cam':'Norm'}</span>
                    <span className="du tc">{c.du}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* slim timeline */}
            <div className="timeline" style={{flexShrink:0}}>
              <div className="tl-toolbar" style={{height:34,gap:6}}>
                <button className="tl-btn"><IconRewind/></button>
                <button className="tl-btn"><IconPlay/></button>
                <span className="sep"></span>
                <span className="tl-tc tc" style={{fontSize:14}}>01:23:45:12</span>
                <span className="sep"></span>
                <span style={{fontSize:9}}>Seq 04 · 4:32</span>
                <div className="grow"></div>
                <button className="tl-btn wide"><span className="plus">＋</span>Cue</button>
                <span className="sep"></span>
                <button className="tl-btn">−</button>
                <button className="tl-btn">+</button>
              </div>

              <div className="tl-ruler" style={{height:18,fontSize:8}}>
                {['1:23:40','1:23:50','1:24:00','1:24:10'].map((t,i)=>(
                  <span key={t} className="tl-tick" style={{left:`${i*25}%`}}>{t}</span>
                ))}
              </div>

              <div className="tl-lanes">
                <div className="tl-playhead" style={{left:'25%'}}></div>

                <div className="tl-lane cam-row" style={{height:40}}>
                  <div className="tl-lane-head" style={{padding:'0 8px'}}>
                    <span style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.12em'}}>CAMS</span>
                    <span style={{flex:1}}></span>
                    <span style={{fontFamily:'var(--mono)',fontSize:8,color:'var(--txt-low)'}}>×5</span>
                  </div>
                  <div className="tl-lane-body">
                    {CAM_CUES.map((c,i)=><CamCue key={i} cue={c}/>)}
                  </div>
                </div>

                <div className="tl-lane" style={{height:32}}>
                  <div className="tl-lane-head" style={{padding:'0 8px',gap:6}}><TrackGlyph code="AUD" size="xs"/></div>
                  <div className="tl-lane-body">
                    <div className="tl-cue aud" style={{left:'0%', width:'100%', top:4, bottom:4}}>
                      <span className="aud-lbl">velocity_master.wav</span>
                      <span className="aud-wave">
                        {wfPattern(110, 7, 0.55).map((v,i)=>(<i key={i} style={{height: Math.max(2, v*18)}}/>))}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="tl-lane" style={{height:32}}>
                  <div className="tl-lane-head" style={{padding:'0 8px',gap:6}}><TrackGlyph code="LX" size="xs"/></div>
                  <div className="tl-lane-body">
                    {LX_CUES.map((c,i)=>(<div className="tl-cue norm" key={i} style={{left:c.l,width:c.w}}>{c.nm}</div>))}
                  </div>
                </div>

                <div className="tl-lane" style={{height:32}}>
                  <div className="tl-lane-head" style={{padding:'0 8px',gap:6}}><TrackGlyph code="VID" size="xs"/></div>
                  <div className="tl-lane-body">
                    {VID_CUES.map((c,i)=>(<div className="tl-cue norm" key={i} style={{left:c.l,width:c.w}}>{c.nm}</div>))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ════════════════════════════════════════════
   CAMERA OP — tablet portrait, split view (my + all)
   On phone this collapses to two separate screens via toggle.
   ════════════════════════════════════════════ */
const MobileCamOpSplit = ({tablet=true}) => (
  <div className="ab" style={{background:'#050507'}}>
    <MobileBar left="CAM 02 · SPLIT VIEW"/>
    <div className="vwr-mobile">
      <MobileOnAirCam
        cam={2}
        name="Wide pull · SR"
        desc="Hold wide thru verse 2. Punch on downbeat."
        held="0:42"
        cutIn="0:12"
        cutSec={12}
        badgeSize="lg"
        extra="t-onair"
      />

      {/* Two stacked panels — my shots (top) + all cams (bottom) */}
      <div style={{flex:1,display:'flex',flexDirection:'column',minHeight:0,overflow:'hidden'}}>
        <div style={{flex:1,minHeight:0,overflow:'hidden',padding:'10px 20px 6px',borderBottom:'1px solid var(--hair)'}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',marginBottom:8}}>
            <span style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.22em',textTransform:'uppercase',color:camCol(2)}}>● My next shots</span>
            <span style={{fontFamily:'var(--mono)',fontSize:9,color:'var(--txt-low)'}}>4 in seq 04</span>
          </div>
          {[
            {nm:'Close · guitar SR',  ds:'Solo tight',           cd:'2:42', cdSec:162},
            {nm:'Wide pull · SR',      ds:'Re-establish wide',    cd:'3:42', cdSec:222},
            {nm:'Mid · guitar',        ds:'Mid lock chorus',      cd:'5:18', cdSec:318},
          ].map((q,i)=>{
            const urgent = q.cdSec <= 10;
            const showBar = q.cdSec <= 20;
            return (
              <div className="m-up-row t-up-row" key={i}>
                <div className="ix">+{i+1}</div>
                <div>
                  <div className="nm">{q.nm}</div>
                  <div className="ds">{q.ds}</div>
                </div>
                <div className={`cd ${urgent?'urgent':(showBar?'warn':'')}`}>{q.cd}</div>
              </div>
            );
          })}
        </div>

        <div style={{flex:1,minHeight:0,overflow:'hidden',padding:'10px 20px 6px'}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',marginBottom:8}}>
            <span style={{fontFamily:'var(--cond)',fontSize:10,fontWeight:700,letterSpacing:'.22em',textTransform:'uppercase',color:'var(--txt-mid)'}}>All cameras · upcoming</span>
            <span style={{fontFamily:'var(--mono)',fontSize:9,color:'var(--txt-low)'}}>5 cuts</span>
          </div>
          {[
            {cam:4, nm:'Close · vocal',   cd:'0:12', cdSec:12},
            {cam:1, nm:'Wide · drone',    cd:'0:18', cdSec:18},
            {cam:3, nm:'Mid · drummer',   cd:'1:50', cdSec:110},
            {cam:5, nm:'Wide · audience', cd:'2:08', cdSec:128},
            {cam:4, nm:'Close · guitar',  cd:'2:42', cdSec:162},
          ].map((q,i)=>{
            const urgent = q.cdSec <= 10;
            const showBar = q.cdSec <= 20;
            return (
              <div className="m-up-row" key={i} style={{padding:'7px 0'}}>
                <CamBadge n={q.cam} size="xs"/>
                <div className="nm" style={{fontSize:15}}>{q.nm}</div>
                <div className={`cd ${urgent?'urgent':(showBar?'warn':'')}`} style={{fontSize:18}}>{q.cd}</div>
                {showBar && (
                  <div className={`urg-bar ${urgent?'urgent':''}`}>
                    <div className="urg-fill" style={{width: Math.max(0,Math.min(100,(20-q.cdSec)/20*100))+'%'}}></div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <MobileFoot left="● CAM 02 · split view" right="~ 1:42 left"/>
    </div>
  </div>
);

/* ════════════════════════════════════════════
   ROOT — design canvas with sections + boards
   ════════════════════════════════════════════ */
const App = () => (
  <DesignCanvas>
    <DCSection id="dir" title="Direction" subtitle="Aesthetic + critique">
      <DCArtboard id="cover" label="A · Cover · direction" width={1440} height={900}>
        <CoverBoard/>
      </DCArtboard>
      <DCArtboard id="analysis" label="B · Analysis" width={1440} height={900}>
        <AnalysisBoard/>
      </DCArtboard>
    </DCSection>

    <DCSection id="live" title="Live cockpit" subtitle="NEXT cue + 4-deep queue, urgency bars at ≤20s. TC demoted. Setlist always visible.">
      <DCArtboard id="live-on" label="LV · 01 · On air · locked" width={1440} height={900}>
        <LiveCockpit state="on-air"/>
      </DCArtboard>
      <DCArtboard id="live-warn" label="LV · 02 · Standby — go in 6" width={1440} height={900}>
        <LiveCockpit state="warn"/>
      </DCArtboard>
      <DCArtboard id="live-pre" label="LV · 03 · Pre-show · no TC" width={1440} height={900}>
        <LiveCockpit state="pre-show"/>
      </DCArtboard>
    </DCSection>

    <DCSection id="camop" title="Camera operator viewer" subtitle="Held shot is the headline. Right panel: my upcoming cuts. Left panel: optional all-cams view — both in the same window.">
      <DCArtboard id="camop-main" label="CAMOP · 01 · Split · my shots + all cams" width={1440} height={900}>
        <CameraOp allCamsOn={true}/>
      </DCArtboard>
      <DCArtboard id="camop-solo" label="CAMOP · 02 · All-cams hidden" width={1440} height={900}>
        <CameraOp allCamsOn={false}/>
      </DCArtboard>
    </DCSection>

    <DCSection id="viewers" title="Track & TC viewers" subtitle="One operator, one track. TC display for stage management.">
      <DCArtboard id="viewer-lx" label="VWR · 01 · Lighting (normal track)" width={1440} height={900}>
        <TrackViewer track={{short:'LX', full:'Lighting'}}/>
      </DCArtboard>
      <DCArtboard id="viewer-vid" label="VWR · 02 · Video" width={1440} height={900}>
        <TrackViewer track={{short:'VID', full:'Video'}}/>
      </DCArtboard>
      <DCArtboard id="tc-on" label="TC · 01 · Locked" width={1440} height={900}>
        <TCViewer state="on-air"/>
      </DCArtboard>
      <DCArtboard id="tc-pre" label="TC · 02 · Pre-show · no signal" width={1440} height={900}>
        <TCViewer state="pre-show"/>
      </DCArtboard>
    </DCSection>

    <DCSection id="responsive" title="Responsive · tablet + phone" subtitle="Every viewer, sized for the screens crew actually use.">
      {/* DIRECTOR */}
      <DCArtboard id="r-director-tablet" label="Director · iPad portrait" width={768} height={1024}>
        <MobileDirector tablet={true}/>
      </DCArtboard>
      <DCArtboard id="r-director-phone" label="Director · phone" width={390} height={844}>
        <MobileDirector tablet={false}/>
      </DCArtboard>

      {/* CAMERA OP */}
      <DCArtboard id="r-camop-tablet" label="Cam op · iPad portrait · split" width={768} height={1024}>
        <MobileCamOpSplit tablet={true}/>
      </DCArtboard>
      <DCArtboard id="r-camop-phone" label="Cam op · phone · my shots" width={390} height={844}>
        <MobileCamOpMain tablet={false}/>
      </DCArtboard>
      <DCArtboard id="r-camop-phone-all" label="Cam op · phone · all cams" width={390} height={844}>
        <MobileCamOpAll tablet={false}/>
      </DCArtboard>

      {/* NORMAL TRACK */}
      <DCArtboard id="r-track-tablet" label="LX viewer · iPad portrait" width={768} height={1024}>
        <MobileTrackViewer tablet={true} track={{short:'LX', full:'Lighting'}}/>
      </DCArtboard>
      <DCArtboard id="r-track-phone" label="LX viewer · phone" width={390} height={844}>
        <MobileTrackViewer tablet={false} track={{short:'LX', full:'Lighting'}}/>
      </DCArtboard>

      {/* TC VIEWER */}
      <DCArtboard id="r-tc-tablet" label="TC · iPad portrait" width={768} height={1024}>
        <MobileTC tablet={true}/>
      </DCArtboard>
      <DCArtboard id="r-tc-landscape" label="TC · iPad landscape · big display" width={1024} height={768}>
        <MobileTC tablet={true} landscape={true}/>
      </DCArtboard>
      <DCArtboard id="r-tc-phone" label="TC · phone" width={390} height={844}>
        <MobileTC tablet={false}/>
      </DCArtboard>

      {/* EDITOR — tablet only (phone impractical) */}
      <DCArtboard id="r-editor-tablet" label="Editor · iPad landscape" width={1024} height={768}>
        <TabletEditor/>
      </DCArtboard>
    </DCSection>

    <DCSection id="edit" title="Edit · planner" subtitle="One camera track. Cues connect (no gaps). Single audio file per sequence.">
      <DCArtboard id="edit-list" label="ED · 01 · Cue list · timeline · inspector" width={1440} height={900}>
        <EditBoard/>
      </DCArtboard>
      <DCArtboard id="edit-newtrack" label="ED · 02 · New-track modal · short + full name" width={1440} height={900}>
        <NewTrackModal/>
      </DCArtboard>
    </DCSection>

    <DCSection id="sys" title="Design system" subtitle="Type · color · components · cam badges · waveforms">
      <DCArtboard id="components" label="SYS · 01 · Components" width={1440} height={900}>
        <ComponentsBoard/>
      </DCArtboard>
    </DCSection>
  </DesignCanvas>
);

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
